//#region dom/locatorScripts/xpathParser.ts
/**
* Parse an XPath expression into a list of traversal steps.
*
* This is a subset parser designed for composed DOM traversal (including
* shadow roots). It intentionally does not implement the full XPath spec.
*
* Supported:
*  - Child (`/`) and descendant (`//`) axes
*  - Tag names and wildcard (`*`)
*  - Positional indices (`[n]`)
*  - Attribute equality predicates (`[@attr='value']`, `[@attr="value"]`)
*  - Attribute existence (`[@attr]`)
*  - Attribute contains/starts-with (`contains(@attr,'v')`, `starts-with(@attr,'v')`)
*  - Text equality/contains (`[text()='v']`, `[contains(text(),'v')]`, `[.='v']`),
*    where `text()` reads direct child text nodes and `.` the whole subtree
*  - normalize-space on text/attributes (`[normalize-space(text())='v']`)
*  - Basic boolean predicates (`and`, `or`, `not(...)`)
*  - Multiple predicates per step (`[@class='foo'][2]`)
*  - Optional `xpath=` prefix
*
* Not supported:
*  - Position functions (`[position() > n]`, `[last()]`)
*  - Axes beyond child/descendant (`ancestor::`, `parent::`, `self::`,
*    `preceding-sibling::`, `following-sibling::`)
*  - Union operator (`|`)
*  - Grouped expressions (`(//div)[n]`)
*
* Unsupported predicates are silently ignored — the step still matches
* by tag name, but the unrecognized predicate has no filtering effect.
*/
function parseXPathSteps(input) {
	const path = String(input || "").trim().replace(/^xpath=/i, "");
	if (!path) return [];
	const steps = [];
	let i = 0;
	while (i < path.length) {
		let axis = "child";
		if (path.startsWith("//", i)) {
			axis = "desc";
			i += 2;
		} else if (path[i] === "/") {
			axis = "child";
			i += 1;
		}
		const start = i;
		let bracketDepth = 0;
		let quote = null;
		while (i < path.length) {
			const ch = path[i];
			if (quote) {
				if (ch === quote) quote = null;
			} else if (ch === "'" || ch === "\"") quote = ch;
			else if (ch === "[") bracketDepth++;
			else if (ch === "]") bracketDepth--;
			else if (ch === "/" && bracketDepth === 0) break;
			i += 1;
		}
		const rawStep = path.slice(start, i).trim();
		if (!rawStep) continue;
		const { tag, predicates } = parseStep(rawStep);
		steps.push({
			axis,
			tag,
			predicates
		});
	}
	return steps;
}
/**
* Extract predicate contents from a string like `[@attr='val'][2]`.
* Handles `]` inside quoted attribute values (e.g. `[@title='a[0]']`).
*/
function extractPredicates(str) {
	const results = [];
	let i = 0;
	while (i < str.length) {
		if (str[i] !== "[") {
			i++;
			continue;
		}
		i++;
		const start = i;
		let quote = null;
		while (i < str.length) {
			const ch = str[i];
			if (quote) {
				if (ch === quote) quote = null;
			} else if (ch === "'" || ch === "\"") quote = ch;
			else if (ch === "]") break;
			i++;
		}
		results.push(str.slice(start, i).trim());
		i++;
	}
	return results;
}
function parseStep(raw) {
	const bracketPos = raw.indexOf("[");
	if (bracketPos === -1) return {
		tag: raw === "" ? "*" : raw.toLowerCase(),
		predicates: []
	};
	const tagPart = raw.slice(0, bracketPos).trim();
	const tag = tagPart === "" ? "*" : tagPart.toLowerCase();
	const predicateStr = raw.slice(bracketPos);
	const predicates = [];
	for (const inner of extractPredicates(predicateStr)) {
		const parsed = parsePredicateExpression(inner);
		if (parsed) predicates.push(parsed);
	}
	return {
		tag,
		predicates
	};
}
function parsePredicateExpression(input) {
	const trimmed = input.trim();
	if (!trimmed) return null;
	const orParts = splitTopLevel(trimmed, "or");
	if (orParts.length > 1) {
		const preds = orParts.map((part) => parsePredicateExpression(part)).filter(Boolean);
		if (preds.length !== orParts.length) return null;
		return {
			type: "or",
			predicates: preds
		};
	}
	const andParts = splitTopLevel(trimmed, "and");
	if (andParts.length > 1) {
		const preds = andParts.map((part) => parsePredicateExpression(part)).filter(Boolean);
		if (preds.length !== andParts.length) return null;
		return {
			type: "and",
			predicates: preds
		};
	}
	const notInner = unwrapFunctionCall(trimmed, "not");
	if (notInner != null) {
		const predicate = parsePredicateExpression(notInner);
		return predicate ? {
			type: "not",
			predicate
		} : null;
	}
	return parseAtomicPredicate(trimmed);
}
function parseAtomicPredicate(input) {
	const valueMatch = /^(?:'([^']*)'|"([^"]*)")$/;
	const attrName = "[a-zA-Z_][\\w.-]*";
	const quoted = "(?:'([^']*)'|\"([^\"]*)\")";
	if (/^\d+$/.test(input)) return {
		type: "index",
		index: Math.max(1, Number(input))
	};
	const normalizeAttrMatch = input.match(new RegExp(`^normalize-space\\(\\s*@(${attrName})\\s*\\)\\s*=\\s*${quoted}$`));
	if (normalizeAttrMatch) return {
		type: "attrEquals",
		name: normalizeAttrMatch[1],
		value: normalizeAttrMatch[2] ?? normalizeAttrMatch[3] ?? "",
		normalize: true
	};
	const normalizeTextMatch = input.match(new RegExp(`^normalize-space\\(\\s*(text\\(\\)|\\.)\\s*\\)\\s*=\\s*${quoted}$`));
	if (normalizeTextMatch) return {
		type: "textEquals",
		value: normalizeTextMatch[2] ?? normalizeTextMatch[3] ?? "",
		normalize: true,
		source: textSource(normalizeTextMatch[1])
	};
	const attrEqualsMatch = input.match(new RegExp(`^@(${attrName})\\s*=\\s*${quoted}$`));
	if (attrEqualsMatch) return {
		type: "attrEquals",
		name: attrEqualsMatch[1],
		value: attrEqualsMatch[2] ?? attrEqualsMatch[3] ?? ""
	};
	const attrExistsMatch = input.match(new RegExp(`^@(${attrName})$`));
	if (attrExistsMatch) return {
		type: "attrExists",
		name: attrExistsMatch[1]
	};
	const attrContainsMatch = input.match(new RegExp(`^contains\\(\\s*@(${attrName})\\s*,\\s*${quoted}\\s*\\)$`));
	if (attrContainsMatch) return {
		type: "attrContains",
		name: attrContainsMatch[1],
		value: attrContainsMatch[2] ?? attrContainsMatch[3] ?? ""
	};
	const attrStartsMatch = input.match(new RegExp(`^starts-with\\(\\s*@(${attrName})\\s*,\\s*${quoted}\\s*\\)$`));
	if (attrStartsMatch) return {
		type: "attrStartsWith",
		name: attrStartsMatch[1],
		value: attrStartsMatch[2] ?? attrStartsMatch[3] ?? ""
	};
	const textEqualsMatch = input.match(new RegExp(`^(text\\(\\)|\\.)\\s*=\\s*${quoted}$`));
	if (textEqualsMatch) return {
		type: "textEquals",
		value: textEqualsMatch[2] ?? textEqualsMatch[3] ?? "",
		source: textSource(textEqualsMatch[1])
	};
	const textContainsMatch = input.match(new RegExp(`^contains\\(\\s*(text\\(\\)|\\.)\\s*,\\s*${quoted}\\s*\\)$`));
	if (textContainsMatch) return {
		type: "textContains",
		value: textContainsMatch[2] ?? textContainsMatch[3] ?? "",
		source: textSource(textContainsMatch[1])
	};
	if (valueMatch.test(input)) return null;
	return null;
}
function splitTopLevel(input, keyword) {
	const parts = [];
	let start = 0;
	let depth = 0;
	let quote = null;
	let i = 0;
	while (i < input.length) {
		const ch = input[i];
		if (quote) {
			if (ch === quote) quote = null;
			i += 1;
			continue;
		}
		if (ch === "'" || ch === "\"") {
			quote = ch;
			i += 1;
			continue;
		}
		if (ch === "(") {
			depth += 1;
			i += 1;
			continue;
		}
		if (ch === ")") {
			depth = Math.max(0, depth - 1);
			i += 1;
			continue;
		}
		if (depth === 0 && isKeywordAt(input, i, keyword)) {
			parts.push(input.slice(start, i).trim());
			i += keyword.length;
			start = i;
			continue;
		}
		i += 1;
	}
	parts.push(input.slice(start).trim());
	return parts.filter((part) => part.length > 0);
}
function isKeywordAt(input, index, keyword) {
	if (!input.startsWith(keyword, index)) return false;
	const before = index > 0 ? input[index - 1] : " ";
	if (before === "@") return false;
	const after = index + keyword.length < input.length ? input[index + keyword.length] : " ";
	return isBoundary(before) && isBoundary(after);
}
function isBoundary(ch) {
	return !/[a-zA-Z0-9_.-]/.test(ch);
}
function unwrapFunctionCall(input, name) {
	const prefix = `${name}(`;
	if (!input.startsWith(prefix) || !input.endsWith(")")) return null;
	const inner = input.slice(prefix.length, -1);
	return hasBalancedParens(inner) ? inner : null;
}
function hasBalancedParens(input) {
	let depth = 0;
	let quote = null;
	for (let i = 0; i < input.length; i += 1) {
		const ch = input[i];
		if (quote) {
			if (ch === quote) quote = null;
			continue;
		}
		if (ch === "'" || ch === "\"") {
			quote = ch;
			continue;
		}
		if (ch === "(") depth += 1;
		else if (ch === ")") depth -= 1;
		if (depth < 0) return false;
	}
	return depth === 0;
}
var normalizeSpace = (value) => value.replace(/\s+/g, " ").trim();
var TEXT_NODE = 3;
function textSource(token) {
	return token === "text()" ? "text" : "self";
}
function textValue(element) {
	return String(element.textContent ?? "");
}
/** The node-set `text()` selects: direct child text nodes, in document order. */
function childTextValues(element) {
	const values = [];
	for (const node of Array.from(element.childNodes)) if (node.nodeType === TEXT_NODE) values.push(String(node.nodeValue ?? ""));
	return values;
}
/** `string(node-set)` is the string-value of its first node, or `""` when empty. */
function firstChildTextValue(element) {
	return childTextValues(element)[0] ?? "";
}
function normalizeMaybe(value, normalize) {
	return normalize ? normalizeSpace(value) : value;
}
function evaluatePredicate(element, predicate) {
	switch (predicate.type) {
		case "and": return predicate.predicates.every((p) => evaluatePredicate(element, p));
		case "or": return predicate.predicates.some((p) => evaluatePredicate(element, p));
		case "not": return !evaluatePredicate(element, predicate.predicate);
		case "attrExists": return element.getAttribute(predicate.name) !== null;
		case "attrEquals": {
			const attr = element.getAttribute(predicate.name);
			if (attr === null) return false;
			return normalizeMaybe(attr, predicate.normalize) === normalizeMaybe(predicate.value, predicate.normalize);
		}
		case "attrContains": {
			const attr = element.getAttribute(predicate.name);
			if (attr === null) return false;
			return normalizeMaybe(attr, predicate.normalize).includes(normalizeMaybe(predicate.value, predicate.normalize));
		}
		case "attrStartsWith": {
			const attr = element.getAttribute(predicate.name);
			if (attr === null) return false;
			return normalizeMaybe(attr, predicate.normalize).startsWith(normalizeMaybe(predicate.value, predicate.normalize));
		}
		case "textEquals": {
			const target = normalizeMaybe(predicate.value, predicate.normalize);
			if (predicate.source === "text") return predicate.normalize ? normalizeSpace(firstChildTextValue(element)) === target : childTextValues(element).some((value) => value === target);
			return normalizeMaybe(textValue(element), predicate.normalize) === target;
		}
		case "textContains": return normalizeMaybe(predicate.source === "text" ? firstChildTextValue(element) : textValue(element), predicate.normalize).includes(normalizeMaybe(predicate.value, predicate.normalize));
		case "index": return true;
		default: return true;
	}
}
function applyPredicates(elements, predicates) {
	let current = elements;
	for (const predicate of predicates) {
		if (!current.length) return [];
		if (predicate.type === "index") {
			const idx = predicate.index - 1;
			current = idx >= 0 && idx < current.length ? [current[idx]] : [];
			continue;
		}
		current = current.filter((el) => evaluatePredicate(el, predicate));
	}
	return current;
}
//#endregion
//#region dom/locatorScripts/shadowRoots.ts
function getOpenOrClosedShadowRoot(element) {
	try {
		if (element instanceof HTMLElement) {
			const root = globalThis.chrome?.dom?.openOrClosedShadowRoot(element);
			if (root) return root;
		}
	} catch {}
	try {
		return element.shadowRoot ?? null;
	} catch {
		return null;
	}
}
function documentHasShadowRoot() {
	try {
		const walker = document.createTreeWalker(document, NodeFilter.SHOW_ELEMENT);
		while (walker.nextNode()) if (getOpenOrClosedShadowRoot(walker.currentNode)) return true;
	} catch {}
	return false;
}
//#endregion
//#region dom/locatorScripts/xpathResolver.ts
var normalizeXPath = (selector) => {
	const raw = String(selector ?? "").trim();
	if (!raw) return "";
	return raw.replace(/^xpath=/i, "").trim();
};
function resolveXPathFirst(rawXp, options) {
	return resolveXPathAtIndex(rawXp, 0, options);
}
function resolveXPathAtIndex(rawXp, index, options) {
	if (!Number.isFinite(index) || index < 0) return null;
	const matches = evaluateXPathMatches(rawXp, options);
	const targetIndex = Math.floor(index);
	if (Array.isArray(matches)) return matches[targetIndex] ?? null;
	return targetIndex < matches.snapshotLength ? matches.snapshotItem(targetIndex) : null;
}
function countXPathMatches(rawXp, options) {
	const matches = evaluateXPathMatches(rawXp, options);
	return Array.isArray(matches) ? matches.length : matches.snapshotLength;
}
function queryXPathMatches(rawXp, options) {
	const matches = evaluateXPathMatches(rawXp, options);
	return Array.isArray(matches) ? matches : Array.from({ length: matches.snapshotLength }, (_, index) => matches.snapshotItem(index));
}
/** Preserve the canonical match order without materializing native snapshots for index/count. */
function evaluateXPathMatches(rawXp, options) {
	const xp = normalizeXPath(rawXp);
	if (!xp) return [];
	const pierceShadow = options?.pierceShadow !== false;
	const shadowCtx = pierceShadow ? getShadowContext() : null;
	if (!shadowCtx?.hasShadow) {
		const native = evaluateNativeXPath(xp);
		if (!pierceShadow || native) return native ?? [];
		return resolveXPathComposedMatches(xp, shadowCtx?.getShadowRoot);
	}
	const shadowHopMatches = resolveStagehandShadowHopMatches(xp, shadowCtx.getShadowRoot);
	if (shadowHopMatches.length > 0) return shadowHopMatches;
	return resolveXPathComposedMatches(xp, shadowCtx.getShadowRoot);
}
function resolveXPathComposedMatches(rawXp, getShadowRoot) {
	const xp = normalizeXPath(rawXp);
	if (!xp) return [];
	const steps = parseXPathSteps(xp);
	if (!steps.length) return [];
	const shadowRootGetter = getShadowRoot ?? null;
	let current = [document];
	for (const step of steps) {
		const next = [];
		const seen = /* @__PURE__ */ new Set();
		for (const root of current) {
			const pool = step.axis === "child" ? composedChildren(root, shadowRootGetter) : composedDescendants(root, shadowRootGetter);
			if (!pool.length) continue;
			const matches = applyPredicates(pool.filter((candidate) => matchesTag(candidate, step)), step.predicates);
			for (const candidate of matches) if (!seen.has(candidate)) {
				seen.add(candidate);
				next.push(candidate);
			}
		}
		if (!next.length) return [];
		current = next;
	}
	return current;
}
function resolveStagehandShadowHopMatches(rawXp, getShadowRoot) {
	const xp = normalizeXPath(rawXp);
	if (!xp) return [];
	const steps = parseXPathSteps(xp);
	if (!steps.some((step, index) => step.axis === "desc" && index > 0)) return [];
	const shadowRootGetter = getShadowRoot ?? null;
	let current = [document];
	for (let i = 0; i < steps.length; i += 1) {
		const step = steps[i];
		const next = [];
		const seen = /* @__PURE__ */ new Set();
		for (const root of current) {
			const pool = step.axis === "child" ? domChildren(root) : i === 0 ? composedDescendants(root, shadowRootGetter) : shadowRootChildren(root, shadowRootGetter);
			if (!pool.length) continue;
			const matches = applyPredicates(pool.filter((candidate) => matchesTag(candidate, step)), step.predicates);
			for (const candidate of matches) if (!seen.has(candidate)) {
				seen.add(candidate);
				next.push(candidate);
			}
		}
		if (!next.length) return [];
		current = next;
	}
	return current;
}
function matchesTag(element, step) {
	if (step.tag === "*") return true;
	return element.localName === step.tag;
}
function getShadowContext() {
	return {
		getShadowRoot: getOpenOrClosedShadowRoot,
		hasShadow: documentHasShadowRoot()
	};
}
function composedChildren(node, getShadowRoot) {
	const out = [];
	if (node instanceof Document) {
		if (node.documentElement) out.push(node.documentElement);
		return out;
	}
	if (node instanceof ShadowRoot || node instanceof DocumentFragment) {
		out.push(...Array.from(node.children ?? []));
		return out;
	}
	if (node instanceof Element) {
		out.push(...Array.from(node.children ?? []));
		const shadowRoot = getShadowRoot?.(node) ?? getOpenOrClosedShadowRoot(node);
		if (shadowRoot) out.push(...Array.from(shadowRoot.children ?? []));
		return out;
	}
	return out;
}
function domChildren(node) {
	const out = [];
	if (node instanceof Document) {
		if (node.documentElement) out.push(node.documentElement);
		return out;
	}
	if (node instanceof ShadowRoot || node instanceof DocumentFragment) {
		out.push(...Array.from(node.children ?? []));
		return out;
	}
	if (node instanceof Element) {
		out.push(...Array.from(node.children ?? []));
		return out;
	}
	return out;
}
function shadowRootChildren(node, getShadowRoot) {
	const out = [];
	if (!(node instanceof Element)) return out;
	const shadowRoot = getShadowRoot?.(node) ?? getOpenOrClosedShadowRoot(node);
	if (shadowRoot) out.push(...Array.from(shadowRoot.children ?? []));
	return out;
}
function composedDescendants(node, getShadowRoot) {
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	const stack = [...composedChildren(node, getShadowRoot)].reverse();
	while (stack.length) {
		const next = stack.pop();
		if (seen.has(next)) continue;
		seen.add(next);
		out.push(next);
		const children = composedChildren(next, getShadowRoot);
		for (let i = children.length - 1; i >= 0; i -= 1) stack.push(children[i]);
	}
	return out;
}
function evaluateNativeXPath(xp) {
	try {
		return document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
	} catch {
		return null;
	}
}
//#endregion
//#region dom/locatorScripts/counts.ts
function countCssMatchesPrimary(selectorRaw) {
	const selector = String(selectorRaw ?? "").trim();
	if (!selector) return 0;
	const seen = /* @__PURE__ */ new WeakSet();
	const visit = (root) => {
		if (!root || seen.has(root)) return 0;
		seen.add(root);
		let total = 0;
		try {
			const queryable = root;
			if (typeof queryable.querySelectorAll === "function") total += queryable.querySelectorAll(selector).length;
		} catch {}
		try {
			const walker = (root instanceof Document ? root : root?.ownerDocument ?? document).createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
			let node;
			while (node = walker.nextNode()) if (node instanceof Element) {
				const shadowRoot = getOpenOrClosedShadowRoot(node);
				if (shadowRoot) total += visit(shadowRoot);
			}
		} catch {}
		return total;
	};
	try {
		return visit(document);
	} catch {
		try {
			return document.querySelectorAll(selector).length;
		} catch {
			return 0;
		}
	}
}
function countTextMatches(rawNeedle) {
	const needle = String(rawNeedle ?? "");
	if (!needle) return {
		count: 0,
		sample: [],
		error: null
	};
	const needleLc = needle.toLowerCase();
	const skipTags = /* @__PURE__ */ new Set([
		"SCRIPT",
		"STYLE",
		"TEMPLATE",
		"NOSCRIPT",
		"HEAD",
		"TITLE",
		"LINK",
		"META",
		"HTML",
		"BODY"
	]);
	const shouldSkip = (node) => {
		if (!node) return false;
		const tag = node.tagName?.toUpperCase() ?? "";
		return skipTags.has(tag);
	};
	const extractText = (element) => {
		try {
			if (shouldSkip(element)) return "";
			const inner = element.innerText;
			if (typeof inner === "string" && inner.trim()) return inner.trim();
		} catch {}
		try {
			const text = element.textContent;
			if (typeof text === "string") return text.trim();
		} catch {}
		return "";
	};
	const matches = (element) => {
		const text = extractText(element);
		return !!text && text.toLowerCase().includes(needleLc);
	};
	const seen = /* @__PURE__ */ new WeakSet();
	const queue = [];
	const enqueue = (node) => {
		if (!node || seen.has(node)) return;
		seen.add(node);
		queue.push(node);
	};
	const walkerFor = (root) => {
		try {
			return (root instanceof Document ? root : root?.ownerDocument ?? document).createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
		} catch {
			return null;
		}
	};
	const matchesList = [];
	enqueue(document);
	while (queue.length) {
		const root = queue.shift();
		if (!root) continue;
		if (root instanceof Element && matches(root)) matchesList.push({
			element: root,
			tag: root.tagName ?? "",
			id: root.id ?? "",
			className: root.className ?? "",
			text: extractText(root)
		});
		const walker = walkerFor(root);
		if (!walker) continue;
		let node;
		while (node = walker.nextNode()) {
			if (!(node instanceof Element)) continue;
			if (matches(node)) matchesList.push({
				element: node,
				tag: node.tagName ?? "",
				id: node.id ?? "",
				className: node.className ?? "",
				text: extractText(node)
			});
			const shadowRoot = getOpenOrClosedShadowRoot(node);
			if (shadowRoot) enqueue(shadowRoot);
		}
	}
	const innermost = [];
	for (const item of matchesList) {
		const el = item.element;
		let skip = false;
		for (const other of matchesList) {
			if (item === other) continue;
			try {
				if (el.contains(other.element)) {
					skip = true;
					break;
				}
			} catch {}
		}
		if (!skip) innermost.push(item);
	}
	return {
		count: innermost.length,
		sample: innermost.slice(0, 5).map((item) => ({
			tag: item.tag,
			id: item.id,
			class: item.className,
			text: item.text
		})),
		error: null
	};
}
function countXPathMatchesMainWorld(rawXp) {
	return countXPathMatches(rawXp, { pierceShadow: true });
}
//#endregion
//#region dom/locatorScripts/cursorOverlay.ts
var CURSOR_OVERLAY_ID = "__v3_cursor_overlay__";
var cursorElement = null;
var pendingPosition = null;
var installScheduled = false;
function positionCursor(element, x, y) {
	element.style.left = `${Math.max(0, x)}px`;
	element.style.top = `${Math.max(0, y)}px`;
}
function scheduleInstall() {
	if (installScheduled) return;
	installScheduled = true;
	const retry = () => {
		installScheduled = false;
		installCursorOverlay();
	};
	document.addEventListener("DOMContentLoaded", retry, { once: true });
	globalThis.setTimeout(retry, 100);
}
function installCursorOverlay() {
	try {
		if (cursorElement?.isConnected) return true;
		const existing = document.getElementById(CURSOR_OVERLAY_ID);
		if (existing instanceof HTMLDivElement) cursorElement = existing;
		else {
			const root = document.documentElement ?? document.body ?? document.head;
			if (!root) {
				scheduleInstall();
				return false;
			}
			const element = document.createElement("div");
			element.id = CURSOR_OVERLAY_ID;
			element.style.position = "fixed";
			element.style.left = "0px";
			element.style.top = "0px";
			element.style.width = "16px";
			element.style.height = "24px";
			element.style.zIndex = "2147483647";
			element.style.pointerEvents = "none";
			element.style.userSelect = "none";
			element.style.mixBlendMode = "normal";
			element.style.contain = "layout style paint";
			element.style.willChange = "transform,left,top";
			element.innerHTML = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"24\" viewBox=\"0 0 16 24\"><path d=\"M1 0 L1 22 L6 14 L15 14 Z\" fill=\"black\" stroke=\"white\" stroke-width=\"0.7\"/></svg>";
			root.appendChild(element);
			cursorElement = element;
		}
		if (pendingPosition) {
			positionCursor(cursorElement, pendingPosition[0], pendingPosition[1]);
			pendingPosition = null;
		}
		return true;
	} catch {
		return false;
	}
}
function moveCursorOverlay(x, y) {
	pendingPosition = [x, y];
	if (!installCursorOverlay() || !cursorElement) return false;
	positionCursor(cursorElement, x, y);
	pendingPosition = null;
	return true;
}
//#endregion
//#region dom/locatorScripts/selectors.ts
var parseTargetIndex = (value) => {
	const num = Number(value ?? 0);
	if (!Number.isFinite(num) || num < 0) return 0;
	return Math.floor(num);
};
var queryLegacyCssSelector = (selector, { limit = Infinity, pierceShadow = true } = {}) => {
	if (!selector) return [];
	const seenRoots = /* @__PURE__ */ new WeakSet();
	const seenElements = /* @__PURE__ */ new Set();
	const results = [];
	const queue = [document];
	const visit = (root) => {
		if (!root || seenRoots.has(root) || results.length >= limit) return;
		seenRoots.add(root);
		try {
			const matches = root.querySelectorAll(selector);
			for (const element of matches) {
				if (seenElements.has(element)) continue;
				seenElements.add(element);
				results.push(element);
				if (results.length >= limit) return;
			}
		} catch {}
		if (!pierceShadow) return;
		try {
			const walker = (root instanceof Document ? root : root.host?.ownerDocument ?? document).createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
			let node;
			while (node = walker.nextNode()) {
				if (!(node instanceof Element)) continue;
				const shadowRoot = getOpenOrClosedShadowRoot(node);
				if (shadowRoot) queue.push(shadowRoot);
			}
		} catch {}
	};
	while (queue.length && results.length < limit) {
		const next = queue.shift();
		if (next) visit(next);
	}
	return results;
};
function resolveCssSelector(selectorRaw, targetIndexRaw) {
	const selector = String(selectorRaw ?? "").trim();
	if (!selector) return null;
	const targetIndex = parseTargetIndex(targetIndexRaw);
	return queryLegacyCssSelector(selector, { limit: targetIndex + 1 })[targetIndex] ?? null;
}
function resolveTextSelector(rawNeedle, targetIndexRaw) {
	return queryLegacyTextSelector(rawNeedle)[parseTargetIndex(targetIndexRaw)] ?? null;
}
/** Legacy text= matching, retained for existing selectors used as a builder's root. */
function queryLegacyTextSelector(rawNeedle, { pierceShadow = true } = {}) {
	const needle = String(rawNeedle ?? "");
	if (!needle) return [];
	const needleLc = needle.toLowerCase();
	const skipTags = /* @__PURE__ */ new Set([
		"SCRIPT",
		"STYLE",
		"TEMPLATE",
		"NOSCRIPT",
		"HEAD",
		"TITLE",
		"LINK",
		"META",
		"HTML",
		"BODY"
	]);
	const shouldSkip = (node) => {
		if (!node) return false;
		const tag = node.tagName?.toUpperCase() ?? "";
		return skipTags.has(tag);
	};
	const extractText = (node) => {
		try {
			if (shouldSkip(node)) return "";
			const inner = node.innerText;
			if (typeof inner === "string" && inner.trim()) return inner.trim();
		} catch {}
		try {
			const text = node.textContent;
			if (typeof text === "string") return text.trim();
		} catch {}
		return "";
	};
	const matches = (node) => {
		const text = extractText(node);
		return !!text && text.toLowerCase().includes(needleLc);
	};
	const seen = /* @__PURE__ */ new WeakSet();
	const queue = [];
	const matchesList = [];
	const enqueue = (node) => {
		if (!node || seen.has(node)) return;
		seen.add(node);
		queue.push(node);
	};
	const walkerFor = (root) => {
		try {
			return (root instanceof Document ? root : root?.ownerDocument ?? document).createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
		} catch {
			return null;
		}
	};
	enqueue(document);
	while (queue.length) {
		const root = queue.shift();
		if (!root) continue;
		if (root instanceof Element && matches(root)) matchesList.push({
			element: root,
			tag: root.tagName ?? "",
			id: root.id ?? "",
			className: root.className ?? "",
			text: extractText(root)
		});
		const walker = walkerFor(root);
		if (!walker) continue;
		let node;
		while (node = walker.nextNode()) {
			if (!(node instanceof Element)) continue;
			if (matches(node)) matchesList.push({
				element: node,
				tag: node.tagName ?? "",
				id: node.id ?? "",
				className: node.className ?? "",
				text: extractText(node)
			});
			const shadowRoot = pierceShadow ? getOpenOrClosedShadowRoot(node) : null;
			if (shadowRoot) enqueue(shadowRoot);
		}
	}
	const innermost = [];
	for (const item of matchesList) {
		const el = item.element;
		let skip = false;
		for (const other of matchesList) {
			if (item === other) continue;
			try {
				if (el.contains(other.element)) {
					skip = true;
					break;
				}
			} catch {}
		}
		if (!skip) innermost.push(item);
	}
	return innermost.map((item) => item.element);
}
function resolveXPathMainWorld(rawXp, targetIndexRaw) {
	return resolveXPathAtIndex(rawXp, parseTargetIndex(targetIndexRaw), { pierceShadow: true });
}
//#endregion
//#region dom/locatorScripts/vendor/playwright/cssTokenizer.ts
var between = function(num, first, last) {
	return num >= first && num <= last;
};
function digit(code) {
	return between(code, 48, 57);
}
function hexdigit(code) {
	return digit(code) || between(code, 65, 70) || between(code, 97, 102);
}
function uppercaseletter(code) {
	return between(code, 65, 90);
}
function lowercaseletter(code) {
	return between(code, 97, 122);
}
function letter(code) {
	return uppercaseletter(code) || lowercaseletter(code);
}
function nonascii(code) {
	return code >= 128;
}
function namestartchar(code) {
	return letter(code) || nonascii(code) || code === 95;
}
function namechar(code) {
	return namestartchar(code) || digit(code) || code === 45;
}
function nonprintable(code) {
	return between(code, 0, 8) || code === 11 || between(code, 14, 31) || code === 127;
}
function newline(code) {
	return code === 10;
}
function whitespace(code) {
	return newline(code) || code === 9 || code === 32;
}
var maximumallowedcodepoint = 1114111;
var InvalidCharacterError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "InvalidCharacterError";
	}
};
function preprocess(str) {
	const codepoints = [];
	for (let i = 0; i < str.length; i++) {
		let code = str.charCodeAt(i);
		if (code === 13 && str.charCodeAt(i + 1) === 10) {
			code = 10;
			i++;
		}
		if (code === 13 || code === 12) code = 10;
		if (code === 0) code = 65533;
		if (between(code, 55296, 56319) && between(str.charCodeAt(i + 1), 56320, 57343)) {
			const lead = code - 55296;
			const trail = str.charCodeAt(i + 1) - 56320;
			code = Math.pow(2, 16) + lead * Math.pow(2, 10) + trail;
			i++;
		}
		codepoints.push(code);
	}
	return codepoints;
}
function stringFromCode(code) {
	if (code <= 65535) return String.fromCharCode(code);
	code -= Math.pow(2, 16);
	const lead = Math.floor(code / Math.pow(2, 10)) + 55296;
	const trail = code % Math.pow(2, 10) + 56320;
	return String.fromCharCode(lead) + String.fromCharCode(trail);
}
function tokenize(str1) {
	const str = preprocess(str1);
	let i = -1;
	const tokens = [];
	let code;
	let line = 0;
	let column = 0;
	let lastLineLength = 0;
	const incrLineno = function() {
		line += 1;
		lastLineLength = column;
		column = 0;
	};
	const locStart = {
		line,
		column
	};
	const codepoint = function(i) {
		if (i >= str.length) return -1;
		return str[i];
	};
	const next = function(num) {
		if (num === void 0) num = 1;
		if (num > 3) throw "Spec Error: no more than three codepoints of lookahead.";
		return codepoint(i + num);
	};
	const consume = function(num) {
		if (num === void 0) num = 1;
		i += num;
		code = codepoint(i);
		if (newline(code)) incrLineno();
		else column += num;
		return true;
	};
	const reconsume = function() {
		i -= 1;
		if (newline(code)) {
			line -= 1;
			column = lastLineLength;
		} else column -= 1;
		locStart.line = line;
		locStart.column = column;
		return true;
	};
	const eof = function(codepoint) {
		if (codepoint === void 0) codepoint = code;
		return codepoint === -1;
	};
	const consumeAToken = function() {
		consumeComments();
		consume();
		if (whitespace(code)) {
			while (whitespace(next())) consume();
			return new WhitespaceToken();
		} else if (code === 34) return consumeAStringToken();
		else if (code === 35) if (namechar(next()) || areAValidEscape(next(1), next(2))) {
			const token = new HashToken("");
			if (wouldStartAnIdentifier(next(1), next(2), next(3))) token.type = "id";
			token.value = consumeAName();
			return token;
		} else return new DelimToken(code);
		else if (code === 36) if (next() === 61) {
			consume();
			return new SuffixMatchToken();
		} else return new DelimToken(code);
		else if (code === 39) return consumeAStringToken();
		else if (code === 40) return new OpenParenToken();
		else if (code === 41) return new CloseParenToken();
		else if (code === 42) if (next() === 61) {
			consume();
			return new SubstringMatchToken();
		} else return new DelimToken(code);
		else if (code === 43) if (startsWithANumber()) {
			reconsume();
			return consumeANumericToken();
		} else return new DelimToken(code);
		else if (code === 44) return new CommaToken();
		else if (code === 45) if (startsWithANumber()) {
			reconsume();
			return consumeANumericToken();
		} else if (next(1) === 45 && next(2) === 62) {
			consume(2);
			return new CDCToken();
		} else if (startsWithAnIdentifier()) {
			reconsume();
			return consumeAnIdentlikeToken();
		} else return new DelimToken(code);
		else if (code === 46) if (startsWithANumber()) {
			reconsume();
			return consumeANumericToken();
		} else return new DelimToken(code);
		else if (code === 58) return new ColonToken();
		else if (code === 59) return new SemicolonToken();
		else if (code === 60) if (next(1) === 33 && next(2) === 45 && next(3) === 45) {
			consume(3);
			return new CDOToken();
		} else return new DelimToken(code);
		else if (code === 64) if (wouldStartAnIdentifier(next(1), next(2), next(3))) return new AtKeywordToken(consumeAName());
		else return new DelimToken(code);
		else if (code === 91) return new OpenSquareToken();
		else if (code === 92) if (startsWithAValidEscape()) {
			reconsume();
			return consumeAnIdentlikeToken();
		} else return new DelimToken(code);
		else if (code === 93) return new CloseSquareToken();
		else if (code === 94) if (next() === 61) {
			consume();
			return new PrefixMatchToken();
		} else return new DelimToken(code);
		else if (code === 123) return new OpenCurlyToken();
		else if (code === 124) if (next() === 61) {
			consume();
			return new DashMatchToken();
		} else if (next() === 124) {
			consume();
			return new ColumnToken();
		} else return new DelimToken(code);
		else if (code === 125) return new CloseCurlyToken();
		else if (code === 126) if (next() === 61) {
			consume();
			return new IncludeMatchToken();
		} else return new DelimToken(code);
		else if (digit(code)) {
			reconsume();
			return consumeANumericToken();
		} else if (namestartchar(code)) {
			reconsume();
			return consumeAnIdentlikeToken();
		} else if (eof()) return new EOFToken();
		else return new DelimToken(code);
	};
	const consumeComments = function() {
		while (next(1) === 47 && next(2) === 42) {
			consume(2);
			while (true) {
				consume();
				if (code === 42 && next() === 47) {
					consume();
					break;
				} else if (eof()) return;
			}
		}
	};
	const consumeANumericToken = function() {
		const num = consumeANumber();
		if (wouldStartAnIdentifier(next(1), next(2), next(3))) {
			const token = new DimensionToken();
			token.value = num.value;
			token.repr = num.repr;
			token.type = num.type;
			token.unit = consumeAName();
			return token;
		} else if (next() === 37) {
			consume();
			const token = new PercentageToken();
			token.value = num.value;
			token.repr = num.repr;
			return token;
		} else {
			const token = new NumberToken();
			token.value = num.value;
			token.repr = num.repr;
			token.type = num.type;
			return token;
		}
	};
	const consumeAnIdentlikeToken = function() {
		const str = consumeAName();
		if (str.toLowerCase() === "url" && next() === 40) {
			consume();
			while (whitespace(next(1)) && whitespace(next(2))) consume();
			if (next() === 34 || next() === 39) return new FunctionToken(str);
			else if (whitespace(next()) && (next(2) === 34 || next(2) === 39)) return new FunctionToken(str);
			else return consumeAURLToken();
		} else if (next() === 40) {
			consume();
			return new FunctionToken(str);
		} else return new IdentToken(str);
	};
	const consumeAStringToken = function(endingCodePoint) {
		if (endingCodePoint === void 0) endingCodePoint = code;
		let string = "";
		while (consume()) if (code === endingCodePoint || eof()) return new StringToken(string);
		else if (newline(code)) {
			reconsume();
			return new BadStringToken();
		} else if (code === 92) if (eof(next()));
		else if (newline(next())) consume();
		else string += stringFromCode(consumeEscape());
		else string += stringFromCode(code);
		throw new Error("Internal error");
	};
	const consumeAURLToken = function() {
		const token = new URLToken("");
		while (whitespace(next())) consume();
		if (eof(next())) return token;
		while (consume()) if (code === 41 || eof()) return token;
		else if (whitespace(code)) {
			while (whitespace(next())) consume();
			if (next() === 41 || eof(next())) {
				consume();
				return token;
			} else {
				consumeTheRemnantsOfABadURL();
				return new BadURLToken();
			}
		} else if (code === 34 || code === 39 || code === 40 || nonprintable(code)) {
			consumeTheRemnantsOfABadURL();
			return new BadURLToken();
		} else if (code === 92) if (startsWithAValidEscape()) token.value += stringFromCode(consumeEscape());
		else {
			consumeTheRemnantsOfABadURL();
			return new BadURLToken();
		}
		else token.value += stringFromCode(code);
		throw new Error("Internal error");
	};
	const consumeEscape = function() {
		consume();
		if (hexdigit(code)) {
			const digits = [code];
			for (let total = 0; total < 5; total++) if (hexdigit(next())) {
				consume();
				digits.push(code);
			} else break;
			if (whitespace(next())) consume();
			let value = parseInt(digits.map(function(x) {
				return String.fromCharCode(x);
			}).join(""), 16);
			if (value > maximumallowedcodepoint) value = 65533;
			return value;
		} else if (eof()) return 65533;
		else return code;
	};
	const areAValidEscape = function(c1, c2) {
		if (c1 !== 92) return false;
		if (newline(c2)) return false;
		return true;
	};
	const startsWithAValidEscape = function() {
		return areAValidEscape(code, next());
	};
	const wouldStartAnIdentifier = function(c1, c2, c3) {
		if (c1 === 45) return namestartchar(c2) || c2 === 45 || areAValidEscape(c2, c3);
		else if (namestartchar(c1)) return true;
		else if (c1 === 92) return areAValidEscape(c1, c2);
		else return false;
	};
	const startsWithAnIdentifier = function() {
		return wouldStartAnIdentifier(code, next(1), next(2));
	};
	const wouldStartANumber = function(c1, c2, c3) {
		if (c1 === 43 || c1 === 45) {
			if (digit(c2)) return true;
			if (c2 === 46 && digit(c3)) return true;
			return false;
		} else if (c1 === 46) {
			if (digit(c2)) return true;
			return false;
		} else if (digit(c1)) return true;
		else return false;
	};
	const startsWithANumber = function() {
		return wouldStartANumber(code, next(1), next(2));
	};
	const consumeAName = function() {
		let result = "";
		while (consume()) if (namechar(code)) result += stringFromCode(code);
		else if (startsWithAValidEscape()) result += stringFromCode(consumeEscape());
		else {
			reconsume();
			return result;
		}
		throw new Error("Internal parse error");
	};
	const consumeANumber = function() {
		let repr = "";
		let type = "integer";
		if (next() === 43 || next() === 45) {
			consume();
			repr += stringFromCode(code);
		}
		while (digit(next())) {
			consume();
			repr += stringFromCode(code);
		}
		if (next(1) === 46 && digit(next(2))) {
			consume();
			repr += stringFromCode(code);
			consume();
			repr += stringFromCode(code);
			type = "number";
			while (digit(next())) {
				consume();
				repr += stringFromCode(code);
			}
		}
		const c1 = next(1);
		const c2 = next(2);
		const c3 = next(3);
		if ((c1 === 69 || c1 === 101) && digit(c2)) {
			consume();
			repr += stringFromCode(code);
			consume();
			repr += stringFromCode(code);
			type = "number";
			while (digit(next())) {
				consume();
				repr += stringFromCode(code);
			}
		} else if ((c1 === 69 || c1 === 101) && (c2 === 43 || c2 === 45) && digit(c3)) {
			consume();
			repr += stringFromCode(code);
			consume();
			repr += stringFromCode(code);
			consume();
			repr += stringFromCode(code);
			type = "number";
			while (digit(next())) {
				consume();
				repr += stringFromCode(code);
			}
		}
		const value = convertAStringToANumber(repr);
		return {
			type,
			value,
			repr
		};
	};
	const convertAStringToANumber = function(string) {
		return +string;
	};
	const consumeTheRemnantsOfABadURL = function() {
		while (consume()) if (code === 41 || eof()) return;
		else if (startsWithAValidEscape()) consumeEscape();
	};
	let iterationCount = 0;
	while (!eof(next())) {
		tokens.push(consumeAToken());
		iterationCount++;
		if (iterationCount > str.length * 2) throw new Error("I'm infinite-looping!");
	}
	return tokens;
}
var CSSParserToken = class {
	constructor() {
		this.tokenType = "";
	}
	toJSON() {
		return { token: this.tokenType };
	}
	toString() {
		return this.tokenType;
	}
	toSource() {
		return "" + this;
	}
};
var BadStringToken = class extends CSSParserToken {
	constructor(..._args) {
		super(..._args);
		this.tokenType = "BADSTRING";
	}
};
var BadURLToken = class extends CSSParserToken {
	constructor(..._args2) {
		super(..._args2);
		this.tokenType = "BADURL";
	}
};
var WhitespaceToken = class extends CSSParserToken {
	constructor(..._args3) {
		super(..._args3);
		this.tokenType = "WHITESPACE";
	}
	toString() {
		return "WS";
	}
	toSource() {
		return " ";
	}
};
var CDOToken = class extends CSSParserToken {
	constructor(..._args4) {
		super(..._args4);
		this.tokenType = "CDO";
	}
	toSource() {
		return "<!--";
	}
};
var CDCToken = class extends CSSParserToken {
	constructor(..._args5) {
		super(..._args5);
		this.tokenType = "CDC";
	}
	toSource() {
		return "-->";
	}
};
var ColonToken = class extends CSSParserToken {
	constructor(..._args6) {
		super(..._args6);
		this.tokenType = ":";
	}
};
var SemicolonToken = class extends CSSParserToken {
	constructor(..._args7) {
		super(..._args7);
		this.tokenType = ";";
	}
};
var CommaToken = class extends CSSParserToken {
	constructor(..._args8) {
		super(..._args8);
		this.tokenType = ",";
	}
};
var GroupingToken = class extends CSSParserToken {
	constructor(..._args9) {
		super(..._args9);
		this.value = "";
		this.mirror = "";
	}
};
var OpenCurlyToken = class extends GroupingToken {
	constructor() {
		super();
		this.tokenType = "{";
		this.value = "{";
		this.mirror = "}";
	}
};
var CloseCurlyToken = class extends GroupingToken {
	constructor() {
		super();
		this.tokenType = "}";
		this.value = "}";
		this.mirror = "{";
	}
};
var OpenSquareToken = class extends GroupingToken {
	constructor() {
		super();
		this.tokenType = "[";
		this.value = "[";
		this.mirror = "]";
	}
};
var CloseSquareToken = class extends GroupingToken {
	constructor() {
		super();
		this.tokenType = "]";
		this.value = "]";
		this.mirror = "[";
	}
};
var OpenParenToken = class extends GroupingToken {
	constructor() {
		super();
		this.tokenType = "(";
		this.value = "(";
		this.mirror = ")";
	}
};
var CloseParenToken = class extends GroupingToken {
	constructor() {
		super();
		this.tokenType = ")";
		this.value = ")";
		this.mirror = "(";
	}
};
var IncludeMatchToken = class extends CSSParserToken {
	constructor(..._args10) {
		super(..._args10);
		this.tokenType = "~=";
	}
};
var DashMatchToken = class extends CSSParserToken {
	constructor(..._args11) {
		super(..._args11);
		this.tokenType = "|=";
	}
};
var PrefixMatchToken = class extends CSSParserToken {
	constructor(..._args12) {
		super(..._args12);
		this.tokenType = "^=";
	}
};
var SuffixMatchToken = class extends CSSParserToken {
	constructor(..._args13) {
		super(..._args13);
		this.tokenType = "$=";
	}
};
var SubstringMatchToken = class extends CSSParserToken {
	constructor(..._args14) {
		super(..._args14);
		this.tokenType = "*=";
	}
};
var ColumnToken = class extends CSSParserToken {
	constructor(..._args15) {
		super(..._args15);
		this.tokenType = "||";
	}
};
var EOFToken = class extends CSSParserToken {
	constructor(..._args16) {
		super(..._args16);
		this.tokenType = "EOF";
	}
	toSource() {
		return "";
	}
};
var DelimToken = class extends CSSParserToken {
	constructor(code) {
		super();
		this.tokenType = "DELIM";
		this.value = "";
		this.value = stringFromCode(code);
	}
	toString() {
		return "DELIM(" + this.value + ")";
	}
	toJSON() {
		const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
		json.value = this.value;
		return json;
	}
	toSource() {
		if (this.value === "\\") return "\\\n";
		else return this.value;
	}
};
var StringValuedToken = class extends CSSParserToken {
	constructor(..._args17) {
		super(..._args17);
		this.value = "";
	}
	ASCIIMatch(str) {
		return this.value.toLowerCase() === str.toLowerCase();
	}
	toJSON() {
		const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
		json.value = this.value;
		return json;
	}
};
var IdentToken = class extends StringValuedToken {
	constructor(val) {
		super();
		this.tokenType = "IDENT";
		this.value = val;
	}
	toString() {
		return "IDENT(" + this.value + ")";
	}
	toSource() {
		return escapeIdent(this.value);
	}
};
var FunctionToken = class extends StringValuedToken {
	constructor(val) {
		super();
		this.tokenType = "FUNCTION";
		this.value = val;
		this.mirror = ")";
	}
	toString() {
		return "FUNCTION(" + this.value + ")";
	}
	toSource() {
		return escapeIdent(this.value) + "(";
	}
};
var AtKeywordToken = class extends StringValuedToken {
	constructor(val) {
		super();
		this.tokenType = "AT-KEYWORD";
		this.value = val;
	}
	toString() {
		return "AT(" + this.value + ")";
	}
	toSource() {
		return "@" + escapeIdent(this.value);
	}
};
var HashToken = class extends StringValuedToken {
	constructor(val) {
		super();
		this.tokenType = "HASH";
		this.value = val;
		this.type = "unrestricted";
	}
	toString() {
		return "HASH(" + this.value + ")";
	}
	toJSON() {
		const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
		json.value = this.value;
		json.type = this.type;
		return json;
	}
	toSource() {
		if (this.type === "id") return "#" + escapeIdent(this.value);
		else return "#" + escapeHash(this.value);
	}
};
var StringToken = class extends StringValuedToken {
	constructor(val) {
		super();
		this.tokenType = "STRING";
		this.value = val;
	}
	toString() {
		return "\"" + escapeString(this.value) + "\"";
	}
};
var URLToken = class extends StringValuedToken {
	constructor(val) {
		super();
		this.tokenType = "URL";
		this.value = val;
	}
	toString() {
		return "URL(" + this.value + ")";
	}
	toSource() {
		return "url(\"" + escapeString(this.value) + "\")";
	}
};
var NumberToken = class extends CSSParserToken {
	constructor() {
		super();
		this.tokenType = "NUMBER";
		this.type = "integer";
		this.repr = "";
	}
	toString() {
		if (this.type === "integer") return "INT(" + this.value + ")";
		return "NUMBER(" + this.value + ")";
	}
	toJSON() {
		const json = super.toJSON();
		json.value = this.value;
		json.type = this.type;
		json.repr = this.repr;
		return json;
	}
	toSource() {
		return this.repr;
	}
};
var PercentageToken = class extends CSSParserToken {
	constructor() {
		super();
		this.tokenType = "PERCENTAGE";
		this.repr = "";
	}
	toString() {
		return "PERCENTAGE(" + this.value + ")";
	}
	toJSON() {
		const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
		json.value = this.value;
		json.repr = this.repr;
		return json;
	}
	toSource() {
		return this.repr + "%";
	}
};
var DimensionToken = class extends CSSParserToken {
	constructor() {
		super();
		this.tokenType = "DIMENSION";
		this.type = "integer";
		this.repr = "";
		this.unit = "";
	}
	toString() {
		return "DIM(" + this.value + "," + this.unit + ")";
	}
	toJSON() {
		const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
		json.value = this.value;
		json.type = this.type;
		json.repr = this.repr;
		json.unit = this.unit;
		return json;
	}
	toSource() {
		const source = this.repr;
		let unit = escapeIdent(this.unit);
		if (unit[0].toLowerCase() === "e" && (unit[1] === "-" || between(unit.charCodeAt(1), 48, 57))) unit = "\\65 " + unit.slice(1, unit.length);
		return source + unit;
	}
};
function escapeIdent(string) {
	string = "" + string;
	let result = "";
	const firstcode = string.charCodeAt(0);
	for (let i = 0; i < string.length; i++) {
		const code = string.charCodeAt(i);
		if (code === 0) throw new InvalidCharacterError("Invalid character: the input contains U+0000.");
		if (between(code, 1, 31) || code === 127 || i === 0 && between(code, 48, 57) || i === 1 && between(code, 48, 57) && firstcode === 45) result += "\\" + code.toString(16) + " ";
		else if (code >= 128 || code === 45 || code === 95 || between(code, 48, 57) || between(code, 65, 90) || between(code, 97, 122)) result += string[i];
		else result += "\\" + string[i];
	}
	return result;
}
function escapeHash(string) {
	string = "" + string;
	let result = "";
	for (let i = 0; i < string.length; i++) {
		const code = string.charCodeAt(i);
		if (code === 0) throw new InvalidCharacterError("Invalid character: the input contains U+0000.");
		if (code >= 128 || code === 45 || code === 95 || between(code, 48, 57) || between(code, 65, 90) || between(code, 97, 122)) result += string[i];
		else result += "\\" + code.toString(16) + " ";
	}
	return result;
}
function escapeString(string) {
	string = "" + string;
	let result = "";
	for (let i = 0; i < string.length; i++) {
		const code = string.charCodeAt(i);
		if (code === 0) throw new InvalidCharacterError("Invalid character: the input contains U+0000.");
		if (between(code, 1, 31) || code === 127) result += "\\" + code.toString(16) + " ";
		else if (code === 34 || code === 92) result += "\\" + string[i];
		else result += string[i];
	}
	return result;
}
//#endregion
//#region dom/locatorScripts/vendor/playwright/domUtils.ts
var globalOptions = {};
function parentElementOrShadowHost(element) {
	if (element.parentElement) return element.parentElement;
	if (!element.parentNode) return;
	if (element.parentNode.nodeType === 11 && element.parentNode.host) return element.parentNode.host;
}
function enclosingShadowRootOrDocument(element) {
	let node = element;
	while (node.parentNode) node = node.parentNode;
	if (node.nodeType === 11 || node.nodeType === 9) return node;
}
function enclosingShadowHost(element) {
	while (element.parentElement) element = element.parentElement;
	return parentElementOrShadowHost(element);
}
function closestCrossShadow(element, css, scope) {
	while (element) {
		const closest = element.closest(css);
		if (scope && closest !== scope && closest?.contains(scope)) return;
		if (closest) return closest;
		element = enclosingShadowHost(element);
	}
}
function getElementComputedStyle(element, pseudo) {
	const cache = pseudo === "::before" ? cacheStyleBefore : pseudo === "::after" ? cacheStyleAfter : cacheStyle;
	if (cache && cache.has(element)) return cache.get(element);
	const style = element.ownerDocument && element.ownerDocument.defaultView ? element.ownerDocument.defaultView.getComputedStyle(element, pseudo) : void 0;
	cache?.set(element, style);
	return style;
}
function isElementStyleVisibilityVisible(element, style) {
	const cached = cacheStyleVisibility?.get(element);
	if (cached !== void 0) return cached;
	const result = computeElementStyleVisibilityVisible(element, style);
	cacheStyleVisibility?.set(element, result);
	return result;
}
function computeElementStyleVisibilityVisible(element, style) {
	style = style ?? getElementComputedStyle(element);
	if (!style) return true;
	if (!element.checkVisibility() && !isWebKitListBoxOptionVisible(element, style)) return false;
	if (style.visibility !== "visible") return false;
	return true;
}
function isListBoxSelect(select) {
	return select.multiple || select.size > 1;
}
function isWebKitListBoxOptionVisible(element, style) {
	if (globalOptions.browserNameForWorkarounds !== "webkit" || element.nodeName !== "OPTION" || style.display === "none") return false;
	const select = element.closest("select");
	if (!select || !isListBoxSelect(select)) return false;
	for (let e = element.parentElement; e && e !== select; e = e.parentElement) if (getElementComputedStyle(e)?.display === "none") return false;
	return isElementStyleVisibilityVisible(select);
}
var kTextNodeRange = Symbol("playwrightTextNodeRange");
function isVisibleTextNode(node) {
	const document = node.ownerDocument;
	const range = document[kTextNodeRange] ??= document.createRange();
	range.selectNode(node);
	const rect = range.getBoundingClientRect();
	const result = rect.width > 0 && rect.height > 0;
	range.setStart(document, 0);
	range.collapse(true);
	return result;
}
function elementSafeTagName(element) {
	const tagName = element.tagName;
	if (typeof tagName === "string") {
		const firstCharCode = tagName.charCodeAt(0);
		if (firstCharCode >= 97 && firstCharCode <= 122) return tagName.toUpperCase();
		return tagName;
	}
	if (element instanceof HTMLFormElement) return "FORM";
	return element.tagName.toUpperCase();
}
var cacheStyle;
var cacheStyleBefore;
var cacheStyleAfter;
var cacheStyleVisibility;
var cachesCounter$1 = 0;
function beginDOMCaches() {
	++cachesCounter$1;
	cacheStyle ??= /* @__PURE__ */ new Map();
	cacheStyleBefore ??= /* @__PURE__ */ new Map();
	cacheStyleAfter ??= /* @__PURE__ */ new Map();
	cacheStyleVisibility ??= /* @__PURE__ */ new Map();
}
function endDOMCaches() {
	if (!--cachesCounter$1) {
		cacheStyle = void 0;
		cacheStyleBefore = void 0;
		cacheStyleAfter = void 0;
		cacheStyleVisibility = void 0;
	}
}
//#endregion
//#region dom/locatorScripts/vendor/playwright/roleUtils.ts
/**
* Copyright (c) Microsoft Corporation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function hasExplicitAccessibleName(e) {
	return e.hasAttribute("aria-label") || e.hasAttribute("aria-labelledby");
}
var kAncestorPreventingLandmark = "article:not([role]), aside:not([role]), main:not([role]), nav:not([role]), section:not([role]), [role=article], [role=complementary], [role=main], [role=navigation], [role=region]";
var kGlobalAriaAttributes = [
	["aria-atomic", void 0],
	["aria-busy", void 0],
	["aria-controls", void 0],
	["aria-current", void 0],
	["aria-describedby", void 0],
	["aria-details", void 0],
	["aria-dropeffect", void 0],
	["aria-flowto", void 0],
	["aria-grabbed", void 0],
	["aria-hidden", void 0],
	["aria-keyshortcuts", void 0],
	["aria-label", [
		"caption",
		"code",
		"deletion",
		"emphasis",
		"generic",
		"insertion",
		"paragraph",
		"presentation",
		"strong",
		"subscript",
		"superscript"
	]],
	["aria-labelledby", [
		"caption",
		"code",
		"deletion",
		"emphasis",
		"generic",
		"insertion",
		"paragraph",
		"presentation",
		"strong",
		"subscript",
		"superscript"
	]],
	["aria-live", void 0],
	["aria-owns", void 0],
	["aria-relevant", void 0],
	["aria-roledescription", ["generic"]]
];
function hasGlobalAriaAttribute(element, forRole) {
	return kGlobalAriaAttributes.some(([attr, prohibited]) => {
		return !prohibited?.includes(forRole || "") && element.hasAttribute(attr);
	});
}
function hasTabIndex(element) {
	return !Number.isNaN(Number(String(element.getAttribute("tabindex"))));
}
function isFocusable(element) {
	return !isNativelyDisabled(element) && (isNativelyFocusable(element) || hasTabIndex(element));
}
function isNativelyFocusable(element) {
	const tagName = elementSafeTagName(element);
	if ([
		"BUTTON",
		"DETAILS",
		"SELECT",
		"TEXTAREA"
	].includes(tagName)) return true;
	if (tagName === "A" || tagName === "AREA") return element.hasAttribute("href");
	if (tagName === "INPUT") return !element.hidden;
	return false;
}
var kImplicitRoleByTagName = {
	"A": (e) => {
		return e.hasAttribute("href") ? "link" : null;
	},
	"AREA": (e) => {
		return e.hasAttribute("href") ? "link" : null;
	},
	"ARTICLE": () => "article",
	"ASIDE": () => "complementary",
	"BLOCKQUOTE": () => "blockquote",
	"BUTTON": () => "button",
	"CAPTION": () => "caption",
	"CODE": () => "code",
	"DATALIST": () => "listbox",
	"DD": () => "definition",
	"DEL": () => "deletion",
	"DETAILS": () => "group",
	"DFN": () => "term",
	"DIALOG": () => "dialog",
	"DT": () => "term",
	"EM": () => "emphasis",
	"FIELDSET": () => "group",
	"FIGURE": () => "figure",
	"FOOTER": (e) => closestCrossShadow(e, kAncestorPreventingLandmark) ? null : "contentinfo",
	"FORM": (e) => hasExplicitAccessibleName(e) ? "form" : null,
	"H1": () => "heading",
	"H2": () => "heading",
	"H3": () => "heading",
	"H4": () => "heading",
	"H5": () => "heading",
	"H6": () => "heading",
	"HEADER": (e) => closestCrossShadow(e, kAncestorPreventingLandmark) ? null : "banner",
	"HR": () => "separator",
	"HTML": () => "document",
	"IMG": (e) => e.getAttribute("alt") === "" && !e.getAttribute("title") && !hasGlobalAriaAttribute(e) && !hasTabIndex(e) ? "presentation" : "img",
	"INPUT": (e) => {
		const type = e.type.toLowerCase();
		if ([
			"email",
			"search",
			"tel",
			"text",
			"url",
			""
		].includes(type)) {
			const list = getIdRefs(e, e.getAttribute("list"))[0];
			if (list && elementSafeTagName(list) === "DATALIST") return "combobox";
			return type === "search" ? "searchbox" : "textbox";
		}
		if (type === "hidden") return null;
		if (type === "file") return "button";
		return inputTypeToRole[type] || "textbox";
	},
	"INS": () => "insertion",
	"LI": () => "listitem",
	"MAIN": () => "main",
	"MARK": () => "mark",
	"MATH": () => "math",
	"MENU": () => "list",
	"METER": () => "meter",
	"NAV": () => "navigation",
	"OL": () => "list",
	"OPTGROUP": () => "group",
	"OPTION": () => "option",
	"OUTPUT": () => "status",
	"P": () => "paragraph",
	"PROGRESS": () => "progressbar",
	"SEARCH": () => "search",
	"SECTION": (e) => hasExplicitAccessibleName(e) ? "region" : null,
	"SELECT": (e) => isListBoxSelect(e) ? "listbox" : "combobox",
	"STRONG": () => "strong",
	"SUB": () => "subscript",
	"SUP": () => "superscript",
	"SVG": () => "img",
	"TABLE": () => "table",
	"TBODY": () => "rowgroup",
	"TD": (e) => {
		const table = closestCrossShadow(e, "table");
		const role = table ? getExplicitAriaRole(table) : "";
		return role === "grid" || role === "treegrid" ? "gridcell" : "cell";
	},
	"TEXTAREA": () => "textbox",
	"TFOOT": () => "rowgroup",
	"TH": (e) => {
		const scope = e.getAttribute("scope");
		if (scope === "col" || scope === "colgroup") return "columnheader";
		if (scope === "row" || scope === "rowgroup") return "rowheader";
		const nextSibling = e.nextElementSibling;
		const prevSibling = e.previousElementSibling;
		const row = !!e.parentElement && elementSafeTagName(e.parentElement) === "TR" ? e.parentElement : void 0;
		if (!nextSibling && !prevSibling) {
			if (row) {
				const table = closestCrossShadow(row, "table");
				if (table && table.rows.length <= 1) return null;
			}
			return "columnheader";
		}
		if (isHeaderCell(nextSibling) && isHeaderCell(prevSibling)) return "columnheader";
		if (isNonEmptyDataCell(nextSibling) || isNonEmptyDataCell(prevSibling)) return "rowheader";
		return "columnheader";
	},
	"THEAD": () => "rowgroup",
	"TIME": () => "time",
	"TR": () => "row",
	"UL": () => "list"
};
function isHeaderCell(element) {
	return !!element && elementSafeTagName(element) === "TH";
}
function isNonEmptyDataCell(element) {
	if (!element || elementSafeTagName(element) !== "TD") return false;
	return !!(element.textContent?.trim() || element.children.length > 0);
}
var kPresentationInheritanceParents = {
	"DD": ["DL", "DIV"],
	"DIV": ["DL"],
	"DT": ["DL", "DIV"],
	"LI": ["OL", "UL"],
	"TBODY": ["TABLE"],
	"TD": ["TR"],
	"TFOOT": ["TABLE"],
	"TH": ["TR"],
	"THEAD": ["TABLE"],
	"TR": [
		"THEAD",
		"TBODY",
		"TFOOT",
		"TABLE"
	]
};
function getImplicitAriaRole(element) {
	const implicitRole = kImplicitRoleByTagName[elementSafeTagName(element)]?.(element) || "";
	if (!implicitRole) return null;
	let ancestor = element;
	while (ancestor) {
		const parent = parentElementOrShadowHost(ancestor);
		const parents = kPresentationInheritanceParents[elementSafeTagName(ancestor)];
		if (!parents || !parent || !parents.includes(elementSafeTagName(parent))) break;
		const parentExplicitRole = getExplicitAriaRole(parent);
		if ((parentExplicitRole === "none" || parentExplicitRole === "presentation") && !hasPresentationConflictResolution(parent, parentExplicitRole)) return parentExplicitRole;
		ancestor = parent;
	}
	return implicitRole;
}
var validRoles = [
	"alert",
	"alertdialog",
	"application",
	"article",
	"banner",
	"blockquote",
	"button",
	"caption",
	"cell",
	"checkbox",
	"code",
	"columnheader",
	"combobox",
	"complementary",
	"contentinfo",
	"definition",
	"deletion",
	"dialog",
	"directory",
	"document",
	"emphasis",
	"feed",
	"figure",
	"form",
	"generic",
	"grid",
	"gridcell",
	"group",
	"heading",
	"img",
	"insertion",
	"link",
	"list",
	"listbox",
	"listitem",
	"log",
	"main",
	"mark",
	"marquee",
	"math",
	"meter",
	"menu",
	"menubar",
	"menuitem",
	"menuitemcheckbox",
	"menuitemradio",
	"navigation",
	"none",
	"note",
	"option",
	"paragraph",
	"presentation",
	"progressbar",
	"radio",
	"radiogroup",
	"region",
	"row",
	"rowgroup",
	"rowheader",
	"scrollbar",
	"search",
	"searchbox",
	"separator",
	"slider",
	"spinbutton",
	"status",
	"strong",
	"subscript",
	"superscript",
	"switch",
	"tab",
	"table",
	"tablist",
	"tabpanel",
	"term",
	"textbox",
	"time",
	"timer",
	"toolbar",
	"tooltip",
	"tree",
	"treegrid",
	"treeitem"
];
function getExplicitAriaRole(element) {
	return (element.getAttribute("role") || "").split(" ").map((role) => role.trim()).find((role) => validRoles.includes(role)) || null;
}
function hasPresentationConflictResolution(element, role) {
	return hasGlobalAriaAttribute(element, role) || isFocusable(element);
}
function getAriaRole(element) {
	const cached = cacheAriaRole?.get(element);
	if (cached !== void 0) return cached;
	const role = computeAriaRole(element);
	cacheAriaRole?.set(element, role);
	return role;
}
function computeAriaRole(element) {
	const explicitRole = getExplicitAriaRole(element);
	if (!explicitRole) return getImplicitAriaRole(element);
	if (explicitRole === "none" || explicitRole === "presentation") {
		const implicitRole = getImplicitAriaRole(element);
		if (hasPresentationConflictResolution(element, implicitRole)) return implicitRole;
	}
	return explicitRole;
}
function getAriaBoolean(attr) {
	return attr === null ? void 0 : attr.toLowerCase() === "true";
}
function isElementIgnoredForAria(element) {
	return [
		"STYLE",
		"SCRIPT",
		"NOSCRIPT",
		"TEMPLATE"
	].includes(elementSafeTagName(element));
}
function isElementHiddenForAria(element) {
	if (isElementIgnoredForAria(element)) return true;
	const style = getElementComputedStyle(element);
	const isSlot = element.nodeName === "SLOT";
	if (style?.display === "contents" && !isSlot) {
		for (let child = element.firstChild; child; child = child.nextSibling) {
			if (child.nodeType === 1 && !isElementHiddenForAria(child)) return false;
			if (child.nodeType === 3 && isVisibleTextNode(child)) return false;
		}
		return true;
	}
	if (!(element.nodeName === "OPTION" && !!element.closest("select")) && !isSlot && !isElementStyleVisibilityVisible(element, style)) return true;
	return belongsToDisplayNoneOrAriaHiddenOrNonSlotted(element);
}
function belongsToDisplayNoneOrAriaHiddenOrNonSlotted(element) {
	let hidden = cacheIsHidden?.get(element);
	if (hidden === void 0) {
		hidden = false;
		if (element.parentElement && element.parentElement.shadowRoot && !element.assignedSlot) hidden = true;
		if (!hidden) {
			const style = getElementComputedStyle(element);
			hidden = !style || style.display === "none" || getAriaBoolean(element.getAttribute("aria-hidden")) === true;
		}
		if (!hidden) {
			const parent = parentElementOrShadowHost(element);
			if (parent) hidden = belongsToDisplayNoneOrAriaHiddenOrNonSlotted(parent);
		}
		cacheIsHidden?.set(element, hidden);
	}
	return hidden;
}
function getIdRefs(element, ref) {
	if (!ref) return [];
	const root = enclosingShadowRootOrDocument(element);
	if (!root) return [];
	try {
		const ids = ref.split(" ").filter((id) => !!id);
		const result = [];
		for (const id of ids) {
			const firstElement = root.querySelector("#" + CSS.escape(id));
			if (firstElement && !result.includes(firstElement)) result.push(firstElement);
		}
		return result;
	} catch (e) {
		return [];
	}
}
function trimFlatString(s) {
	return s.trim();
}
function asFlatString(s) {
	return s.split("\xA0").map((chunk) => chunk.replace(/\r\n/g, "\n").replace(/[\u200b\u00ad]/g, "").replace(/\s\s*/g, " ")).join("\xA0").trim();
}
function queryInAriaOwned(element, selector) {
	const result = [...element.querySelectorAll(selector)];
	for (const owned of getIdRefs(element, element.getAttribute("aria-owns"))) {
		if (owned.matches(selector)) result.push(owned);
		result.push(...owned.querySelectorAll(selector));
	}
	return result;
}
function getCSSContent(element, pseudo) {
	const cache = pseudo === "::before" ? cachePseudoContentBefore : pseudo === "::after" ? cachePseudoContentAfter : cachePseudoContent;
	if (cache?.has(element)) return cache?.get(element);
	const style = getElementComputedStyle(element, pseudo);
	let content;
	if (style) {
		const contentValue = style.content;
		if (contentValue && contentValue !== "none" && contentValue !== "normal") {
			if (style.display !== "none" && style.visibility !== "hidden") content = parseCSSContentPropertyAsString(element, contentValue, !!pseudo);
		}
	}
	if (pseudo && content !== void 0) {
		if ((style?.display || "inline") !== "inline") content = " " + content + " ";
	}
	if (cache) cache.set(element, content);
	return content;
}
function parseCSSContentPropertyAsString(element, content, isPseudo) {
	if (!content || content === "none" || content === "normal") return;
	try {
		let tokens = tokenize(content).filter((token) => !(token instanceof WhitespaceToken));
		const delimIndex = tokens.findIndex((token) => token instanceof DelimToken && token.value === "/");
		if (delimIndex !== -1) tokens = tokens.slice(delimIndex + 1);
		else if (!isPseudo) return;
		const accumulated = [];
		let index = 0;
		while (index < tokens.length) if (tokens[index] instanceof StringToken) {
			accumulated.push(tokens[index].value);
			index++;
		} else if (index + 2 < tokens.length && tokens[index] instanceof FunctionToken && tokens[index].value === "attr" && tokens[index + 1] instanceof IdentToken && tokens[index + 2] instanceof CloseParenToken) {
			const attrName = tokens[index + 1].value;
			accumulated.push(element.getAttribute(attrName) || "");
			index += 3;
		} else return;
		return accumulated.join("");
	} catch {}
}
function getAriaLabelledByElements(element) {
	const ref = element.getAttribute("aria-labelledby");
	if (ref === null) return null;
	const refs = getIdRefs(element, ref);
	return refs.length ? refs : null;
}
function allowsNameFromContent(role, targetDescendant) {
	const alwaysAllowsNameFromContent = [
		"button",
		"cell",
		"checkbox",
		"columnheader",
		"gridcell",
		"heading",
		"link",
		"menuitem",
		"menuitemcheckbox",
		"menuitemradio",
		"option",
		"radio",
		"row",
		"rowheader",
		"switch",
		"tab",
		"tooltip",
		"treeitem"
	].includes(role);
	const descendantAllowsNameFromContent = targetDescendant && [
		"",
		"caption",
		"code",
		"contentinfo",
		"definition",
		"deletion",
		"emphasis",
		"insertion",
		"list",
		"listitem",
		"mark",
		"none",
		"paragraph",
		"presentation",
		"region",
		"row",
		"rowgroup",
		"section",
		"strong",
		"subscript",
		"superscript",
		"table",
		"term",
		"time"
	].includes(role);
	return alwaysAllowsNameFromContent || descendantAllowsNameFromContent;
}
function computeAccessibleNameComposite(element, includeHidden, collectElements) {
	if ([
		"caption",
		"code",
		"definition",
		"deletion",
		"emphasis",
		"generic",
		"insertion",
		"mark",
		"paragraph",
		"presentation",
		"strong",
		"subscript",
		"suggestion",
		"superscript",
		"term",
		"time"
	].includes(getAriaRole(element) || "")) return {
		...emptyCompositeString(),
		derivedFromContent: false
	};
	const outDerivedFromContent = { value: false };
	const result = getTextAlternativeInternal(element, {
		includeHidden,
		collectElements,
		outDerivedFromContent,
		visitedElements: /* @__PURE__ */ new Set(),
		embeddedInTargetElement: "self"
	});
	return {
		text: asFlatString(result.text),
		elements: result.elements,
		derivedFromContent: outDerivedFromContent.value
	};
}
function getElementAccessibleNameText(element, includeHidden) {
	const composite = (includeHidden ? cacheAccessibleNameHidden : cacheAccessibleName)?.get(element);
	if (composite !== void 0) return composite.text;
	const cache = includeHidden ? cacheAccessibleNameTextHidden : cacheAccessibleNameText;
	let text = cache?.get(element);
	if (text === void 0) {
		text = computeAccessibleNameComposite(element, includeHidden, false).text;
		cache?.set(element, text);
	}
	return text;
}
function getElementAccessibleDescription(element, includeHidden) {
	const cache = includeHidden ? cacheAccessibleDescriptionHidden : cacheAccessibleDescription;
	let accessibleDescription = cache?.get(element);
	if (accessibleDescription === void 0) {
		accessibleDescription = {
			text: "",
			derivedFromContent: false
		};
		if (element.hasAttribute("aria-describedby")) {
			const describedBy = getIdRefs(element, element.getAttribute("aria-describedby"));
			accessibleDescription.text = asFlatString(describedBy.map((ref) => getTextAlternativeInternal(ref, {
				includeHidden,
				visitedElements: /* @__PURE__ */ new Set(),
				embeddedInDescribedBy: {
					element: ref,
					hidden: isElementHiddenForAria(ref)
				}
			}).text).join(" "));
			accessibleDescription.derivedFromContent = describedBy.some((ref) => ref === element || element.contains(ref));
		} else if (element.hasAttribute("aria-description")) accessibleDescription.text = asFlatString(element.getAttribute("aria-description") || "");
		else accessibleDescription.text = asFlatString(element.getAttribute("title") || "");
		cache?.set(element, accessibleDescription);
	}
	return accessibleDescription;
}
function insideTargetElement(options) {
	return options.embeddedInTargetElement === "self" || options.embeddedInTargetElement === "descendant";
}
function getTextAlternativeInternal(element, options) {
	if (options.visitedElements.has(element)) return emptyCompositeString();
	const childOptions = {
		...options,
		embeddedInTargetElement: options.embeddedInTargetElement === "self" ? "descendant" : options.embeddedInTargetElement
	};
	if (!options.includeHidden) {
		const isEmbeddedInHiddenReferenceTraversal = !!options.embeddedInLabelledBy?.hidden || !!options.embeddedInDescribedBy?.hidden || !!options.embeddedInNativeTextAlternative?.hidden || !!options.embeddedInLabel?.hidden;
		if (isElementIgnoredForAria(element) || !isEmbeddedInHiddenReferenceTraversal && isElementHiddenForAria(element)) {
			options.visitedElements.add(element);
			return emptyCompositeString();
		}
	}
	const labelledBy = getAriaLabelledByElements(element);
	if (!options.embeddedInLabelledBy) {
		const accessibleName = joinCompositeString((labelledBy || []).map((ref) => getTextAlternativeInternal(ref, {
			...options,
			embeddedInLabelledBy: {
				element: ref,
				hidden: isElementHiddenForAria(ref)
			},
			embeddedInDescribedBy: void 0,
			embeddedInTargetElement: void 0,
			embeddedInLabel: void 0,
			embeddedInNativeTextAlternative: void 0
		})), " ", options.collectElements);
		if (accessibleName.text) {
			if (options.outDerivedFromContent && insideTargetElement(options) && (labelledBy || []).some((ref) => ref === element || element.contains(ref))) options.outDerivedFromContent.value = true;
			return accessibleName;
		}
	}
	const role = getAriaRole(element) || "";
	const tagName = elementSafeTagName(element);
	if (!!options.embeddedInLabel || !!options.embeddedInLabelledBy || options.embeddedInTargetElement === "descendant") {
		const isOwnLabel = [...element.labels || []].includes(element);
		const isOwnLabelledBy = (labelledBy || []).includes(element);
		if (!isOwnLabel && !isOwnLabelledBy) {
			if (role === "textbox" || role === "searchbox") {
				options.visitedElements.add(element);
				if (tagName === "INPUT" || tagName === "TEXTAREA") return compositeString(element.value, element, options.collectElements);
				return compositeString(element.textContent, element, options.collectElements);
			}
			if (["combobox", "listbox"].includes(role)) {
				options.visitedElements.add(element);
				let selectedOptions;
				if (tagName === "SELECT") {
					selectedOptions = [...element.selectedOptions];
					if (!selectedOptions.length && element.options.length) selectedOptions.push(element.options[0]);
				} else {
					const listbox = role === "combobox" ? queryInAriaOwned(element, "*").find((e) => getAriaRole(e) === "listbox") : element;
					selectedOptions = listbox ? queryInAriaOwned(listbox, "[aria-selected=\"true\"]").filter((e) => getAriaRole(e) === "option") : [];
				}
				if (!selectedOptions.length && tagName === "INPUT") return compositeString(element.value, element, options.collectElements);
				return joinCompositeString(selectedOptions.map((option) => getTextAlternativeInternal(option, childOptions)), " ", options.collectElements);
			}
			if ([
				"progressbar",
				"scrollbar",
				"slider",
				"spinbutton",
				"meter"
			].includes(role)) {
				options.visitedElements.add(element);
				if (element.hasAttribute("aria-valuetext")) return compositeString(element.getAttribute("aria-valuetext"), element, options.collectElements);
				if (element.hasAttribute("aria-valuenow")) return compositeString(element.getAttribute("aria-valuenow"), element, options.collectElements);
				return compositeString(element.getAttribute("value"), element, options.collectElements);
			}
			if (["menu"].includes(role)) {
				options.visitedElements.add(element);
				return emptyCompositeString();
			}
		}
	}
	const ariaLabel = element.getAttribute("aria-label") || "";
	if (trimFlatString(ariaLabel)) {
		options.visitedElements.add(element);
		return compositeString(ariaLabel, element, options.collectElements);
	}
	if (!["presentation", "none"].includes(role)) {
		if (tagName === "INPUT" && [
			"button",
			"submit",
			"reset"
		].includes(element.type)) {
			options.visitedElements.add(element);
			const value = element.value || "";
			if (trimFlatString(value)) return compositeString(value, element, options.collectElements);
			if (element.type === "submit") return compositeString("Submit", element, options.collectElements);
			if (element.type === "reset") return compositeString("Reset", element, options.collectElements);
			return compositeString(element.getAttribute("title") || "", element, options.collectElements);
		}
		if (tagName === "INPUT" && element.type === "file") {
			options.visitedElements.add(element);
			const labels = element.labels || [];
			if (labels.length && !options.embeddedInLabelledBy) return getAccessibleNameFromAssociatedLabels(labels, options);
			return compositeString("Choose File", element, options.collectElements);
		}
		if (tagName === "INPUT" && element.type === "image") {
			options.visitedElements.add(element);
			const labels = element.labels || [];
			if (labels.length && !options.embeddedInLabelledBy) return getAccessibleNameFromAssociatedLabels(labels, options);
			const alt = element.getAttribute("alt") || "";
			if (trimFlatString(alt)) return compositeString(alt, element, options.collectElements);
			const title = element.getAttribute("title") || "";
			if (trimFlatString(title)) return compositeString(title, element, options.collectElements);
			return compositeString("Submit", element, options.collectElements);
		}
		if (!labelledBy && tagName === "BUTTON") {
			options.visitedElements.add(element);
			const labels = element.labels || [];
			if (labels.length) return getAccessibleNameFromAssociatedLabels(labels, options);
		}
		if (!labelledBy && tagName === "OUTPUT") {
			options.visitedElements.add(element);
			const labels = element.labels || [];
			if (labels.length) return getAccessibleNameFromAssociatedLabels(labels, options);
			return compositeString(element.getAttribute("title") || "", element, options.collectElements);
		}
		if (!labelledBy && (tagName === "TEXTAREA" || tagName === "SELECT" || tagName === "INPUT" || tagName === "METER" || tagName === "PROGRESS")) {
			options.visitedElements.add(element);
			const labels = element.labels || [];
			if (labels.length) return getAccessibleNameFromAssociatedLabels(labels, options);
			const usePlaceholder = tagName === "INPUT" && [
				"text",
				"password",
				"number",
				"search",
				"tel",
				"email",
				"url"
			].includes(element.type) || tagName === "TEXTAREA";
			const placeholder = element.getAttribute("placeholder") || "";
			const title = element.getAttribute("title") || "";
			if (!usePlaceholder || title) return compositeString(title, element, options.collectElements);
			return compositeString(placeholder, element, options.collectElements);
		}
		if (!labelledBy && tagName === "FIELDSET") {
			options.visitedElements.add(element);
			for (let child = element.firstElementChild; child; child = child.nextElementSibling) if (elementSafeTagName(child) === "LEGEND") return getTextAlternativeInternal(child, {
				...childOptions,
				embeddedInNativeTextAlternative: {
					element: child,
					hidden: isElementHiddenForAria(child)
				}
			});
			return compositeString(element.getAttribute("title") || "", element, options.collectElements);
		}
		if (!labelledBy && tagName === "FIGURE") {
			options.visitedElements.add(element);
			for (let child = element.firstElementChild; child; child = child.nextElementSibling) if (elementSafeTagName(child) === "FIGCAPTION") return getTextAlternativeInternal(child, {
				...childOptions,
				embeddedInNativeTextAlternative: {
					element: child,
					hidden: isElementHiddenForAria(child)
				}
			});
			return compositeString(element.getAttribute("title") || "", element, options.collectElements);
		}
		if (tagName === "IMG") {
			options.visitedElements.add(element);
			const alt = element.getAttribute("alt") || "";
			if (trimFlatString(alt)) return compositeString(alt, element, options.collectElements);
			return compositeString(element.getAttribute("title") || "", element, options.collectElements);
		}
		if (tagName === "TABLE") {
			options.visitedElements.add(element);
			for (let child = element.firstElementChild; child; child = child.nextElementSibling) if (elementSafeTagName(child) === "CAPTION") return getTextAlternativeInternal(child, {
				...childOptions,
				embeddedInNativeTextAlternative: {
					element: child,
					hidden: isElementHiddenForAria(child)
				}
			});
			const summary = element.getAttribute("summary") || "";
			if (summary) return compositeString(summary, element, options.collectElements);
		}
		if (tagName === "AREA") {
			options.visitedElements.add(element);
			const alt = element.getAttribute("alt") || "";
			if (trimFlatString(alt)) return compositeString(alt, element, options.collectElements);
			return compositeString(element.getAttribute("title") || "", element, options.collectElements);
		}
		if (tagName === "SVG" || element.ownerSVGElement) {
			options.visitedElements.add(element);
			for (let child = element.firstElementChild; child; child = child.nextElementSibling) if (elementSafeTagName(child) === "TITLE" && child.ownerSVGElement) return getTextAlternativeInternal(child, {
				...childOptions,
				embeddedInLabelledBy: {
					element: child,
					hidden: isElementHiddenForAria(child)
				}
			});
		}
		if (element.ownerSVGElement && tagName === "A") {
			const title = element.getAttribute("xlink:title") || "";
			if (trimFlatString(title)) {
				options.visitedElements.add(element);
				return compositeString(title, element, options.collectElements);
			}
		}
	}
	const shouldNameFromContentForSummary = tagName === "SUMMARY" && !["presentation", "none"].includes(role);
	if (allowsNameFromContent(role, options.embeddedInTargetElement === "descendant") || shouldNameFromContentForSummary || !!options.embeddedInLabelledBy || !!options.embeddedInDescribedBy || !!options.embeddedInLabel || !!options.embeddedInNativeTextAlternative) {
		options.visitedElements.add(element);
		const accessibleName = innerAccumulatedElementText(element, childOptions);
		if (options.embeddedInTargetElement === "self" ? trimFlatString(accessibleName.text) : accessibleName.text) {
			if (options.outDerivedFromContent && insideTargetElement(options) && trimFlatString(accessibleName.text)) options.outDerivedFromContent.value = true;
			accessibleName.elements?.add(element);
			return accessibleName;
		}
	}
	if (!["presentation", "none"].includes(role) || tagName === "IFRAME" || tagName === "FRAME") {
		options.visitedElements.add(element);
		const title = element.getAttribute("title") || "";
		if (trimFlatString(title)) return compositeString(title, element, options.collectElements);
	}
	options.visitedElements.add(element);
	return emptyCompositeString();
}
function innerAccumulatedElementText(element, options) {
	const tokens = [];
	const elements = options.collectElements ? /* @__PURE__ */ new Set() : void 0;
	const visit = (node, skipSlotted) => {
		if (skipSlotted && node.assignedSlot) return;
		if (node.nodeType === 1) {
			const display = getElementComputedStyle(node)?.display || "inline";
			const childComposite = getTextAlternativeInternal(node, options);
			let token = childComposite.text;
			for (const contributor of childComposite.elements || []) elements?.add(contributor);
			if (display !== "inline" || node.nodeName === "BR") token = " " + token + " ";
			tokens.push(token);
		} else if (node.nodeType === 3) tokens.push(node.textContent || "");
	};
	tokens.push(getCSSContent(element, "::before") || "");
	const content = getCSSContent(element);
	if (content !== void 0) tokens.push(content);
	else {
		const assignedNodes = element.nodeName === "SLOT" ? element.assignedNodes() : [];
		if (assignedNodes.length) for (const child of assignedNodes) visit(child, false);
		else {
			for (let child = element.firstChild; child; child = child.nextSibling) visit(child, true);
			if (element.shadowRoot) for (let child = element.shadowRoot.firstChild; child; child = child.nextSibling) visit(child, true);
			for (const owned of getIdRefs(element, element.getAttribute("aria-owns"))) visit(owned, true);
		}
	}
	tokens.push(getCSSContent(element, "::after") || "");
	return {
		text: tokens.join(""),
		elements
	};
}
var kAriaSelectedRoles = [
	"gridcell",
	"option",
	"row",
	"tab",
	"rowheader",
	"columnheader",
	"treeitem"
];
function getAriaSelected(element) {
	if (elementSafeTagName(element) === "OPTION") return element.selected;
	if (kAriaSelectedRoles.includes(getAriaRole(element) || "")) return getAriaBoolean(element.getAttribute("aria-selected")) === true;
	return false;
}
var kAriaCheckedRoles = [
	"checkbox",
	"menuitemcheckbox",
	"option",
	"radio",
	"switch",
	"menuitemradio",
	"treeitem"
];
function getAriaChecked(element) {
	const result = getChecked(element, true);
	return result === "error" ? false : result;
}
function getChecked(element, allowMixed) {
	const tagName = elementSafeTagName(element);
	if (allowMixed && tagName === "INPUT" && element.indeterminate) return "mixed";
	if (tagName === "INPUT" && ["checkbox", "radio"].includes(element.type)) return element.checked;
	if (kAriaCheckedRoles.includes(getAriaRole(element) || "")) {
		const checked = element.getAttribute("aria-checked");
		if (checked === "true") return true;
		if (allowMixed && checked === "mixed") return "mixed";
		return false;
	}
	return "error";
}
var kAriaPressedRoles = ["button"];
function getAriaPressed(element) {
	if (kAriaPressedRoles.includes(getAriaRole(element) || "")) {
		const pressed = element.getAttribute("aria-pressed");
		if (pressed === "true") return true;
		if (pressed === "mixed") return "mixed";
	}
	return false;
}
var kAriaExpandedRoles = [
	"application",
	"button",
	"checkbox",
	"combobox",
	"gridcell",
	"link",
	"listbox",
	"menuitem",
	"row",
	"rowheader",
	"tab",
	"treeitem",
	"columnheader",
	"menuitemcheckbox",
	"menuitemradio",
	"rowheader",
	"switch"
];
function getAriaExpanded(element) {
	if (elementSafeTagName(element) === "DETAILS") return element.open;
	if (kAriaExpandedRoles.includes(getAriaRole(element) || "")) {
		const expanded = element.getAttribute("aria-expanded");
		if (expanded === null) return void 0;
		if (expanded === "true") return true;
		return false;
	}
}
var kAriaLevelRoles = [
	"heading",
	"listitem",
	"row",
	"treeitem"
];
function getAriaLevel(element) {
	const native = {
		"H1": 1,
		"H2": 2,
		"H3": 3,
		"H4": 4,
		"H5": 5,
		"H6": 6
	}[elementSafeTagName(element)];
	if (native) return native;
	if (kAriaLevelRoles.includes(getAriaRole(element) || "")) {
		const attr = element.getAttribute("aria-level");
		const value = attr === null ? NaN : Number(attr);
		if (Number.isInteger(value) && value >= 1) return value;
	}
	return 0;
}
var kAriaDisabledRoles = [
	"application",
	"button",
	"composite",
	"gridcell",
	"group",
	"input",
	"link",
	"menuitem",
	"scrollbar",
	"separator",
	"tab",
	"checkbox",
	"columnheader",
	"combobox",
	"grid",
	"listbox",
	"menu",
	"menubar",
	"menuitemcheckbox",
	"menuitemradio",
	"option",
	"radio",
	"radiogroup",
	"row",
	"rowheader",
	"searchbox",
	"select",
	"slider",
	"spinbutton",
	"switch",
	"tablist",
	"textbox",
	"toolbar",
	"tree",
	"treegrid",
	"treeitem"
];
function getAriaDisabled(element) {
	return isNativelyDisabled(element) || hasExplicitAriaDisabled(element);
}
function isNativelyDisabled(element) {
	return [
		"BUTTON",
		"INPUT",
		"SELECT",
		"TEXTAREA",
		"OPTION",
		"OPTGROUP"
	].includes(elementSafeTagName(element)) && (element.hasAttribute("disabled") || belongsToDisabledOptGroup(element) || belongsToDisabledFieldSet(element));
}
function belongsToDisabledOptGroup(element) {
	return elementSafeTagName(element) === "OPTION" && !!element.closest("OPTGROUP[DISABLED]");
}
function belongsToDisabledFieldSet(element) {
	const fieldSetElement = element?.closest("FIELDSET[DISABLED]");
	if (!fieldSetElement) return false;
	const legendElement = fieldSetElement.querySelector(":scope > LEGEND");
	return !legendElement || !legendElement.contains(element);
}
function hasExplicitAriaDisabled(element) {
	if (!kAriaDisabledRoles.includes(getAriaRole(element) || "")) return false;
	return hasAriaDisabledInChain(element);
}
function hasAriaDisabledInChain(element) {
	let result = cacheAriaDisabled?.get(element);
	if (result === void 0) {
		const attribute = (element.getAttribute("aria-disabled") || "").toLowerCase();
		if (attribute === "true") result = true;
		else if (attribute === "false") result = false;
		else {
			const parent = parentElementOrShadowHost(element);
			result = parent ? hasAriaDisabledInChain(parent) : false;
		}
		cacheAriaDisabled?.set(element, result);
	}
	return result;
}
function getAccessibleNameFromAssociatedLabels(labels, options) {
	return joinCompositeString([...labels].map((label) => getTextAlternativeInternal(label, {
		...options,
		embeddedInLabel: {
			element: label,
			hidden: isElementHiddenForAria(label)
		},
		embeddedInNativeTextAlternative: void 0,
		embeddedInLabelledBy: void 0,
		embeddedInDescribedBy: void 0,
		embeddedInTargetElement: void 0
	})).filter((accessibleName) => !!accessibleName.text), " ", options.collectElements);
}
var cacheAccessibleName;
var cacheAccessibleNameHidden;
var cacheAccessibleNameText;
var cacheAccessibleNameTextHidden;
var cacheAccessibleDescription;
var cacheAccessibleDescriptionHidden;
var cacheAccessibleErrorMessage;
var cacheIsHidden;
var cachePseudoContent;
var cachePseudoContentBefore;
var cachePseudoContentAfter;
var cachePointerEvents;
var cacheAriaRole;
var cacheAriaDisabled;
var cachesCounter = 0;
function beginAriaCaches() {
	beginDOMCaches();
	++cachesCounter;
	cacheAriaRole ??= /* @__PURE__ */ new Map();
	cacheAriaDisabled ??= /* @__PURE__ */ new Map();
	cacheAccessibleName ??= /* @__PURE__ */ new Map();
	cacheAccessibleNameHidden ??= /* @__PURE__ */ new Map();
	cacheAccessibleNameText ??= /* @__PURE__ */ new Map();
	cacheAccessibleNameTextHidden ??= /* @__PURE__ */ new Map();
	cacheAccessibleDescription ??= /* @__PURE__ */ new Map();
	cacheAccessibleDescriptionHidden ??= /* @__PURE__ */ new Map();
	cacheAccessibleErrorMessage ??= /* @__PURE__ */ new Map();
	cacheIsHidden ??= /* @__PURE__ */ new Map();
	cachePseudoContent ??= /* @__PURE__ */ new Map();
	cachePseudoContentBefore ??= /* @__PURE__ */ new Map();
	cachePseudoContentAfter ??= /* @__PURE__ */ new Map();
	cachePointerEvents ??= /* @__PURE__ */ new Map();
}
function endAriaCaches() {
	if (!--cachesCounter) {
		cacheAccessibleName = void 0;
		cacheAccessibleNameHidden = void 0;
		cacheAccessibleNameText = void 0;
		cacheAccessibleNameTextHidden = void 0;
		cacheAccessibleDescription = void 0;
		cacheAccessibleDescriptionHidden = void 0;
		cacheAccessibleErrorMessage = void 0;
		cacheIsHidden = void 0;
		cachePseudoContent = void 0;
		cachePseudoContentBefore = void 0;
		cachePseudoContentAfter = void 0;
		cachePointerEvents = void 0;
		cacheAriaRole = void 0;
		cacheAriaDisabled = void 0;
	}
	endDOMCaches();
}
var inputTypeToRole = {
	"button": "button",
	"checkbox": "checkbox",
	"image": "button",
	"number": "spinbutton",
	"radio": "radio",
	"range": "slider",
	"reset": "button",
	"submit": "button"
};
function emptyCompositeString() {
	return { text: "" };
}
function compositeString(text, element, collectElements) {
	return {
		text: text || "",
		elements: text && collectElements ? /* @__PURE__ */ new Set([element]) : void 0
	};
}
function joinCompositeString(parts, separator, collectElements) {
	let elements;
	if (collectElements) {
		elements = /* @__PURE__ */ new Set();
		for (const part of parts) for (const element of part.elements || []) elements.add(element);
	}
	return {
		text: parts.map((part) => part.text).join(separator),
		elements
	};
}
//#endregion
//#region dom/locatorScripts/vendor/playwright/stringUtils.ts
var normalizedWhitespaceCache;
function normalizeWhiteSpace(text) {
	let result = normalizedWhitespaceCache?.get(text);
	if (result === void 0) {
		result = text.replace(/[\u200b\u00ad]/g, "").trim().replace(/\s+/g, " ");
		normalizedWhitespaceCache?.set(text, result);
	}
	return result;
}
//#endregion
//#region dom/locatorScripts/vendor/playwright/selectorUtils.ts
/**
* Copyright (c) Microsoft Corporation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function matchesAttributePart(value, attr) {
	const objValue = typeof value === "string" && !attr.caseSensitive ? value.toUpperCase() : value;
	const attrValue = typeof attr.value === "string" && !attr.caseSensitive ? attr.value.toUpperCase() : attr.value;
	if (attr.op === "<truthy>") return !!objValue;
	if (attr.op === "=") {
		if (attrValue instanceof RegExp) {
			attrValue.lastIndex = 0;
			return typeof objValue === "string" && !!objValue.match(attrValue);
		}
		return objValue === attrValue;
	}
	if (typeof objValue !== "string" || typeof attrValue !== "string") return false;
	if (attr.op === "*=") return objValue.includes(attrValue);
	if (attr.op === "^=") return objValue.startsWith(attrValue);
	if (attr.op === "$=") return objValue.endsWith(attrValue);
	if (attr.op === "|=") return objValue === attrValue || objValue.startsWith(attrValue + "-");
	if (attr.op === "~=") return objValue.split(" ").includes(attrValue);
	return false;
}
function shouldSkipForTextMatching(element) {
	const document = element.ownerDocument;
	return element.nodeName === "SCRIPT" || element.nodeName === "NOSCRIPT" || element.nodeName === "STYLE" || document.head && document.head.contains(element);
}
function elementText(cache, root) {
	let value = cache.get(root);
	if (value === void 0) {
		value = {
			full: "",
			normalized: "",
			immediate: []
		};
		if (!shouldSkipForTextMatching(root)) {
			let currentImmediate = "";
			if (root instanceof HTMLInputElement && (root.type === "submit" || root.type === "button" || root.type === "reset")) value = {
				full: root.value,
				normalized: normalizeWhiteSpace(root.value),
				immediate: [root.value]
			};
			else {
				for (let child = root.firstChild; child; child = child.nextSibling) if (child.nodeType === Node.TEXT_NODE) {
					value.full += child.nodeValue || "";
					currentImmediate += child.nodeValue || "";
				} else if (child.nodeType === Node.COMMENT_NODE) continue;
				else {
					if (currentImmediate) value.immediate.push(currentImmediate);
					currentImmediate = "";
					if (child.nodeType === Node.ELEMENT_NODE) value.full += elementText(cache, child).full;
				}
				if (currentImmediate) value.immediate.push(currentImmediate);
				if (root.shadowRoot) value.full += elementText(cache, root.shadowRoot).full;
				if (value.full) value.normalized = normalizeWhiteSpace(value.full);
			}
		}
		cache.set(root, value);
	}
	return value;
}
function elementMatchesText(cache, element, matcher) {
	if (shouldSkipForTextMatching(element)) return "none";
	if (!matcher(elementText(cache, element))) return "none";
	for (let child = element.firstChild; child; child = child.nextSibling) if (child.nodeType === Node.ELEMENT_NODE && matcher(elementText(cache, child))) return "selfAndChildren";
	if (element.shadowRoot && matcher(elementText(cache, element.shadowRoot))) return "selfAndChildren";
	return "self";
}
//#endregion
//#region dom/locatorScripts/semanticSelectors.ts
/** Resolve a locator afresh, keeping all DOM/ARIA caches inside this synchronous query. */
function querySemanticSelector(steps, root = document, { pierceShadow = true } = {}) {
	let roots = [root];
	const textCache = /* @__PURE__ */ new Map();
	beginAriaCaches();
	try {
		for (const [stepIndex, step] of steps.entries()) {
			if (step.kind === "nth") {
				roots = roots[step.index] ? [roots[step.index]] : [];
				continue;
			}
			const query = step.kind === "role" ? roleQuery(step, pierceShadow) : step.kind === "text" ? textQuery(step, textCache, pierceShadow) : (scope) => selectorQuery(step.selector, scope, pierceShadow, stepIndex === 0);
			const matches = /* @__PURE__ */ new Set();
			for (const scope of roots) for (const element of query(scope)) matches.add(element);
			roots = [...matches];
		}
		return roots.filter((node) => node instanceof Element);
	} finally {
		endAriaCaches();
	}
}
function resolveSemanticSelector(steps, index = 0, options) {
	return querySemanticSelector(steps, document, options)[index] ?? null;
}
function countSemanticMatches(steps, options) {
	return querySemanticSelector(steps, document, options).length;
}
function roleQuery(step, pierceShadow) {
	const { role, options = {} } = step;
	const supportedStates = [
		["checked", kAriaCheckedRoles],
		["pressed", kAriaPressedRoles],
		["selected", kAriaSelectedRoles],
		["expanded", kAriaExpandedRoles],
		["level", kAriaLevelRoles]
	];
	for (const [state, roles] of supportedStates) if (options[state] !== void 0 && !roles.includes(role)) throw new Error(`"${state}" attribute is only supported for roles: ${roles.slice().sort().map((value) => `"${value}"`).join(", ")}`);
	const nameMatcher = options.name === void 0 ? void 0 : accessibleTextMatcher(options.name, !!options.exact);
	const descriptionMatcher = options.description === void 0 ? void 0 : accessibleTextMatcher(options.description, !!options.exact);
	return (scope) => queryElements(scope, "*", pierceShadow).filter((element) => {
		if (getAriaRole(element) !== role) return false;
		if (options.checked !== void 0 && getAriaChecked(element) !== options.checked) return false;
		if (options.pressed !== void 0 && getAriaPressed(element) !== options.pressed) return false;
		if (options.selected !== void 0 && getAriaSelected(element) !== options.selected) return false;
		if (options.expanded !== void 0 && getAriaExpanded(element) !== options.expanded) return false;
		if (options.level !== void 0 && getAriaLevel(element) !== options.level) return false;
		if (options.disabled !== void 0 && getAriaDisabled(element) !== options.disabled) return false;
		if (!options.includeHidden && isElementHiddenForAria(element)) return false;
		if (nameMatcher && !nameMatcher(normalizeWhiteSpace(getElementAccessibleNameText(element, !!options.includeHidden)))) return false;
		return !descriptionMatcher || descriptionMatcher(normalizeWhiteSpace(getElementAccessibleDescription(element, !!options.includeHidden).text));
	});
}
function accessibleTextMatcher(pattern, exact) {
	const attribute = {
		name: "",
		jsonPath: [],
		op: typeof pattern === "string" && !exact ? "*=" : "=",
		value: typeof pattern === "string" ? normalizeWhiteSpace(pattern) : new RegExp(pattern.source, pattern.flags),
		caseSensitive: typeof pattern !== "string" || exact
	};
	return (value) => matchesAttributePart(value, attribute);
}
function textQuery({ text, exact }, cache, pierceShadow) {
	let matcher;
	if (typeof text !== "string") {
		const regex = new RegExp(text.source, text.flags);
		matcher = ({ full }) => {
			regex.lastIndex = 0;
			return regex.test(full);
		};
	} else {
		const expected = normalizeWhiteSpace(text);
		matcher = exact ? ({ normalized }) => normalized === expected : ({ normalized }) => normalized.toLowerCase().includes(expected.toLowerCase());
	}
	return (scope) => {
		const candidates = queryElements(scope, "*", pierceShadow);
		if (scope instanceof Element) candidates.unshift(scope);
		return candidates.filter((element) => elementMatchesText(cache, element, matcher) === "self");
	};
}
/** Match light DOM before open shadow roots, preserving Playwright's query order. */
function queryElements(scope, selector, pierceShadow) {
	const result = [...scope.querySelectorAll(selector)];
	if (!pierceShadow) return result;
	const shadows = [];
	if (scope instanceof Element && scope.shadowRoot) shadows.push(scope.shadowRoot);
	for (const element of scope.querySelectorAll("*")) if (element.shadowRoot) shadows.push(element.shadowRoot);
	for (const shadow of shadows) result.push(...queryElements(shadow, selector, true));
	return result;
}
function selectorQuery(raw, scope, pierceShadow, initial) {
	const selector = raw.trim();
	if (/^text=/i.test(selector)) {
		if (!initial || !(scope instanceof Document)) throw new Error("Nested text= selectors are not supported; use getByText() instead");
		let text = selector.replace(/^text=/i, "").trim();
		if (text.startsWith("\"") && text.endsWith("\"") || text.startsWith("'") && text.endsWith("'")) text = text.slice(1, -1);
		return queryLegacyTextSelector(text, { pierceShadow });
	}
	const isXPath = /^xpath=/i.test(selector) || /^(?:\(|\.\/|\/)/.test(selector);
	if (initial && scope instanceof Document) return isXPath ? queryXPathMatches(selector, { pierceShadow }) : queryLegacyCssSelector(selector.replace(/^css=/i, ""), { pierceShadow });
	if (!isXPath) return queryElements(scope, selector.replace(/^css=/i, ""), pierceShadow);
	let expression = selector.replace(/^xpath=/i, "");
	if (scope instanceof Element && expression.startsWith("/")) expression = "." + expression;
	const iterator = (scope instanceof Document ? scope : scope.ownerDocument).evaluate(expression, scope, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE);
	const result = [];
	let node;
	while (node = iterator.iterateNext()) if (node instanceof Element) result.push(node);
	return result;
}
//#endregion
//#region dom/locatorScripts/waitForSelector.ts
/**
* waitForSelector - Waits for an element matching a selector to reach a specific state.
* Supports both CSS selectors and XPath expressions.
* Uses MutationObserver for efficiency and the extension DOM API for closed shadow roots.
*
* NOTE: This function runs inside the page context. Keep it dependency-free
* and resilient to exceptions.
*/
/**
* Check if a selector is an XPath expression.
*/
var isXPath = (selector) => {
	return selector.startsWith("xpath=") || selector.startsWith("/");
};
/**
* Deep querySelector that pierces both open and closed shadow DOM.
*/
var deepQuerySelector = (root, selector, pierceShadow) => {
	try {
		const el = root.querySelector(selector);
		if (el) return el;
	} catch {}
	if (!pierceShadow) return null;
	const seenRoots = /* @__PURE__ */ new WeakSet();
	const queue = [root];
	while (queue.length > 0) {
		const currentRoot = queue.shift();
		if (!currentRoot || seenRoots.has(currentRoot)) continue;
		seenRoots.add(currentRoot);
		try {
			const found = currentRoot.querySelector(selector);
			if (found) return found;
		} catch {}
		try {
			const walker = (currentRoot instanceof Document ? currentRoot : currentRoot.host?.ownerDocument ?? document).createTreeWalker(currentRoot, NodeFilter.SHOW_ELEMENT);
			let node;
			while (node = walker.nextNode()) {
				if (!(node instanceof Element)) continue;
				const shadowRoot = getOpenOrClosedShadowRoot(node);
				if (shadowRoot && !seenRoots.has(shadowRoot)) queue.push(shadowRoot);
			}
		} catch {}
	}
	return null;
};
/**
* Resolve XPath with shadow DOM piercing support.
*/
var deepXPathQuery = (xpath, pierceShadow) => {
	return resolveXPathFirst(xpath, { pierceShadow });
};
/**
* Find element by selector (CSS or XPath) with optional shadow DOM piercing.
*/
var findElement = (selector, pierceShadow) => {
	if (isXPath(selector)) return deepXPathQuery(selector, pierceShadow);
	return deepQuerySelector(document, selector, pierceShadow);
};
/**
* Check if element matches the desired state.
*/
var checkState = (el, state) => {
	if (state === "detached") return el === null;
	if (state === "attached") return el !== null;
	if (el === null) return state === "hidden";
	if (state === "hidden") try {
		const style = window.getComputedStyle(el);
		const rect = el.getBoundingClientRect();
		return style.display === "none" || style.visibility === "hidden" || style.opacity === "0" || rect.width === 0 || rect.height === 0;
	} catch {
		return false;
	}
	try {
		const style = window.getComputedStyle(el);
		const rect = el.getBoundingClientRect();
		return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0" && rect.width > 0 && rect.height > 0;
	} catch {
		return false;
	}
};
/**
* Set up MutationObservers on all shadow roots to detect changes.
*/
var setupShadowObservers = (callback, observers, isSettled, options) => {
	const seenRoots = /* @__PURE__ */ new WeakSet();
	const observeShadowRoots = (node) => {
		const shadowRoot = getOpenOrClosedShadowRoot(node);
		if (shadowRoot && !seenRoots.has(shadowRoot)) {
			seenRoots.add(shadowRoot);
			const shadowObserver = new MutationObserver(() => {
				callback();
				scan();
			});
			observers.push(shadowObserver);
			shadowObserver.observe(shadowRoot, options);
			for (const child of Array.from(shadowRoot.children)) observeShadowRoots(child);
		}
		for (const child of Array.from(node.children)) observeShadowRoots(child);
	};
	const root = document.documentElement || document.body;
	const scan = () => {
		if (!isSettled() && root) observeShadowRoots(root);
	};
	scan();
	return scan;
};
/**
* Wait for an element matching the selector to reach the specified state.
* Supports both CSS selectors and XPath expressions (prefix with "xpath=" or start with "/").
*
* @param selectorRaw - CSS selector or XPath expression to wait for
* @param stateRaw - Element state: 'attached' | 'detached' | 'visible' | 'hidden'
* @param timeoutRaw - Maximum time to wait in milliseconds; defaults to 30,000, zero is unlimited
* @param pierceShadowRaw - Whether to search inside shadow DOM
* @returns A disposable handle whose promise resolves when the condition is met
*/
function createSelectorWait(selectorRaw, stateRaw, timeoutRaw, pierceShadowRaw) {
	const selector = typeof selectorRaw === "string" ? selectorRaw.trim() : JSON.stringify(selectorRaw);
	const state = String(stateRaw ?? "visible") || "visible";
	const timeout = typeof timeoutRaw === "number" && timeoutRaw >= 0 ? timeoutRaw : 3e4;
	const pierceShadow = pierceShadowRaw !== false;
	const steps = typeof selectorRaw === "string" ? void 0 : selectorRaw;
	const query = steps ? () => querySemanticSelector(steps, document, { pierceShadow })[0] ?? null : () => findElement(selector, pierceShadow);
	const observationOptions = {
		childList: true,
		subtree: true,
		attributes: true,
		...steps ? { characterData: true } : { attributeFilter: [
			"style",
			"class",
			"hidden",
			"disabled"
		] }
	};
	let dispose = () => {};
	const promise = new Promise((resolve, reject) => {
		let settled = false;
		let timeoutId;
		let pollInterval;
		let domReadyHandler;
		let rescanShadowRoots;
		const observers = [];
		const settle = (error) => {
			if (settled) return;
			settled = true;
			clearTimeout(timeoutId);
			clearInterval(pollInterval);
			for (const observer of observers) observer.disconnect();
			observers.length = 0;
			rescanShadowRoots = void 0;
			if (domReadyHandler) {
				document.removeEventListener("DOMContentLoaded", domReadyHandler);
				domReadyHandler = void 0;
			}
			if (error) reject(error);
			else resolve(true);
		};
		dispose = () => settle(/* @__PURE__ */ new Error("Selector wait disposed"));
		const check = () => {
			if (settled) return;
			try {
				if (checkState(query(), state)) settle();
			} catch (error) {
				settle(error instanceof Error ? error : new Error(String(error)));
			}
		};
		const setupObservers = () => {
			if (settled) return;
			const root = document.body || document.documentElement;
			if (!root) return;
			try {
				const mainObserver = new MutationObserver(() => {
					check();
					rescanShadowRoots?.();
				});
				observers.push(mainObserver);
				mainObserver.observe(root, observationOptions);
				if (pierceShadow) rescanShadowRoots = setupShadowObservers(check, observers, () => settled, observationOptions);
				if (pierceShadow || steps) pollInterval = setInterval(() => {
					rescanShadowRoots?.();
					check();
				}, 100);
			} catch (error) {
				settle(error instanceof Error ? error : new Error(String(error)));
			}
		};
		check();
		if (settled) return;
		if (document.body || document.documentElement) setupObservers();
		else {
			domReadyHandler = () => {
				if (settled) return;
				document.removeEventListener("DOMContentLoaded", domReadyHandler);
				domReadyHandler = void 0;
				check();
				setupObservers();
			};
			document.addEventListener("DOMContentLoaded", domReadyHandler);
		}
		if (!settled && timeout > 0) timeoutId = setTimeout(() => settle(/* @__PURE__ */ new Error(`waitForSelector: Timeout ${timeout}ms exceeded waiting for "${selector}" to be ${state}`)), timeout);
	});
	promise.catch(() => {});
	return {
		promise,
		dispose: () => dispose()
	};
}
//#endregion
//#region dom/locatorScripts/registry.ts
var locatorScripts = Object.freeze({
	countCssMatchesPrimary,
	countTextMatches,
	countXPathMatchesMainWorld,
	getOpenOrClosedShadowRoot,
	installCursorOverlay,
	moveCursorOverlay,
	resolveCssSelector,
	resolveTextSelector,
	resolveXPathMainWorld,
	createSelectorWait,
	countSemanticMatches,
	resolveSemanticSelector
});
//#endregion
//#region content-script.ts
var scope = globalThis;
if (!scope.__stagehandExtensionWorld) Object.defineProperty(scope, "__stagehandExtensionWorld", {
	configurable: false,
	enumerable: false,
	writable: false,
	value: Object.freeze({
		name: "stagehand",
		version: "stagehand.v4"
	})
});
if (!scope.__stagehandLocatorScripts) Object.defineProperty(scope, "__stagehandLocatorScripts", {
	configurable: false,
	enumerable: false,
	writable: false,
	value: locatorScripts
});
if (!scope.__stagehandLocatorWorld) {
	const closedShadowRoots = typeof globalThis.chrome?.dom?.openOrClosedShadowRoot === "function";
	Object.defineProperty(scope, "__stagehandLocatorWorld", {
		configurable: false,
		enumerable: false,
		writable: false,
		value: Object.freeze({
			kind: closedShadowRoots ? "extension" : "cdp-fallback",
			closedShadowRoots
		})
	});
}
//#endregion
